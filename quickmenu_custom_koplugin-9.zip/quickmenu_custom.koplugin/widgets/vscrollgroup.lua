-- VScrollGroup: wraps a single child widget and caps its visible height.
-- When the child is taller than `height`, the wrapped content can be
-- dragged (pan) or swiped vertically to reveal the rest.
--
-- Coordinates: the child is always painted with the REAL absolute screen
-- x/y it would normally receive (just offset vertically), so nested
-- InputContainer widgets (buttons, action chips, etc.) keep correct
-- `dimen` values and their own taps keep working unmodified. Clipping the
-- drawn pixels to the viewport is attempted via bb:viewport() when
-- available; if that method isn't present on this KOReader build, drawing
-- falls back to unclipped (content may bleed past the section's edges
-- when scrolled, but scrolling and taps still work correctly).
--
-- Registered like other drag widgets: `{ slider = vscroll }` in refs.sliders.

local Geom   = require("ui/geometry")
local Device = require("device")
local Screen = Device.screen

local VScrollGroup = {}
VScrollGroup.__index = VScrollGroup

function VScrollGroup:new(o)
    o = o or {}
    setmetatable(o, self)
    o.offset = o.offset or 0
    return o
end

function VScrollGroup:_maxOffset()
    local child_h = self.child and self.child:getSize().h or 0
    return math.max(0, child_h - self.height)
end

function VScrollGroup:getSize()
    local child_h = self.child and self.child:getSize().h or 0
    return Geom:new{ w = self.width, h = math.min(self.height, child_h) }
end

function VScrollGroup:paintTo(bb, x, y)
    local size = self:getSize()
    self.dimen = Geom:new{ x = x, y = y, w = size.w, h = size.h }
    if not self.child then return end

    local max_offset = self:_maxOffset()
    self.offset = math.max(0, math.min(max_offset, self.offset))

    if max_offset <= 0 then
        self.child:paintTo(bb, x, y)
        return
    end

    local ok, view = pcall(function() return bb:viewport(self.dimen) end)
    if ok and view then
        self.child:paintTo(view, x, y - self.offset)
    else
        -- No clipping available on this build: draw unclipped rather than crash.
        self.child:paintTo(bb, x, y - self.offset)
    end
end

function VScrollGroup:handlePan(ges)
    if self._dragging then
        local dy = ges.pos.y - self._pan_start_y
        if math.abs(dy) > Screen:scaleBySize(4) then self._dragged = true end
        self.offset = math.max(0, math.min(self:_maxOffset(), self._pan_start_offset - dy))
        return true
    end
    if not (self.dimen and ges.pos:intersectWith(self.dimen)) then return false end
    if self:_maxOffset() <= 0 then return false end
    local dir = ges.direction
    if dir == "east" or dir == "west" then return false end -- let horizontal drags (e.g. the ToC row) take it
    self._dragging = true
    self._dragged = false
    self._pan_start_y = ges.pos.y
    self._pan_start_offset = self.offset
    return true
end

function VScrollGroup:handlePanRelease(_ges)
    local was = self._dragging
    self._dragging = false
    self._pan_start_y = nil
    self._pan_start_offset = nil
    return was
end

function VScrollGroup:handleTap(ges)
    if not self.dimen or not ges.pos:intersectWith(self.dimen) then return false end
    if self._dragged then self._dragged = false; return true end -- swallow tap that ended a drag
    return false -- not a drag: let the normal button under the finger handle it
end

function VScrollGroup:handleSwipe(ges)
    if not self.dimen or not ges.pos:intersectWith(self.dimen) then return false end
    local max_offset = self:_maxOffset()
    if max_offset <= 0 then return false end
    local step = self.height * 0.6
    if ges.direction == "north" then self.offset = math.min(max_offset, self.offset + step)
    elseif ges.direction == "south" then self.offset = math.max(0, self.offset - step)
    else return false end
    return true
end

function VScrollGroup:handleMultiSwipe(_ges) return false end
function VScrollGroup:handleEvent(_event) return false end

return VScrollGroup
