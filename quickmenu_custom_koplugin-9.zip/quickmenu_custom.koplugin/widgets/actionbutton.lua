local InputContainer = require("ui/widget/container/inputcontainer")
local FrameContainer = require("ui/widget/container/framecontainer")
local CenterContainer = require("ui/widget/container/centercontainer")
local VerticalGroup = require("ui/widget/verticalgroup")
local VerticalSpan = require("ui/widget/verticalspan")
local TextWidget = require("ui/widget/textwidget")
local IconWidget = require("ui/widget/iconwidget")

local GestureRange = require("ui/gesturerange")
local Geom = require("ui/geometry")

local Blitbuffer = require("ffi/blitbuffer")
local Font = require("ui/font")
local UIManager = require("ui/uimanager")
local ShadowDeco = require("widgets/shadow_deco")

local CircleButton = InputContainer:extend{
    icon = nil,
    size = 64,
    width = nil,  -- overrides `size` for width only; falls back to `size` when nil
    height = nil, -- overrides `size` for height only; falls back to `size` when nil
    icon_size = 26,
    radius = 32,
    is_active = false,
    bordersize = 0,
    callback = nil,
    hold_callback = nil,
    bg_active = Blitbuffer.COLOR_LIGHT_GRAY,
    bg_inactive = Blitbuffer.COLOR_WHITE,
    no_active_bg = false, -- when true, background never changes with is_active (only the inner icon updates)
    label = nil,      -- optional: when set, drawn INSIDE the box below the icon (box grows to fit)
    label_face = nil, -- font face for `label`; falls back to a small default
    label_gap = 2,    -- vertical gap between icon and inside label
}

function CircleButton:init()
    local content_widget
    local icon_val = self.icon or ""
    local w = self.width or self.size
    local h = self.height or self.size

    -- On cherche si la chaîne correspond au format [icon=nom_icone]
    local extracted_icon = icon_val:match("^%[icon=(.+)%]$")

    if extracted_icon then
        content_widget = IconWidget:new{
            icon  = extracted_icon,
            width = h * 0.4, -- TODO Hack : sized off height so width-stretch doesn't distort the icon
            height = h * 0.4,
            alpha = true,
        }
        self.icon_widget = nil -- not text-updatable
    else
        -- Sinon, on traite le contenu comme un caractère Unicode (ou un texte/nombre)
        content_widget = TextWidget:new{
            text = self.icon or "",
            face = Font:getFace("cfont", self.icon_size),
            color = Blitbuffer.COLOR_BLACK,
        }
        self.icon_widget = content_widget -- kept so updateIcon() can swap the text live
    end

    -- Création du cercle (le widget visuel)
    local frame_h = h
    if self.label and self.label ~= "" then
        local label_widget = TextWidget:new{
            text = self.label,
            face = self.label_face or Font:getFace("cfont", 12),
            max_width = math.max(1, w - (self.bordersize * 2) - 4),
        }
        local label_h = label_widget:getSize().h
        content_widget = VerticalGroup:new{
            align = "center",
            content_widget,
            VerticalSpan:new{ width = self.label_gap },
            label_widget,
        }
        frame_h = h + label_h + self.label_gap
    end

    self.circle = FrameContainer:new{
        width = w,
        height = frame_h,
        radius = self.radius,
        bordersize = self.bordersize,
        background = (self.is_active and not self.no_active_bg) and self.bg_active or self.bg_inactive,
        padding = 0,
        CenterContainer:new{
            dimen = Geom:new{
                w = w - (self.bordersize * 2),
                h = frame_h - (self.bordersize * 2),
            },
            content_widget
        }
    }
    ShadowDeco.attach(self.circle)

    self[1] = self.circle

    self.dimen = self:getSize()

    self.ges_events = {
        TapSelect = { GestureRange:new{ ges = "tap", range = self.dimen } },
        HoldSelect = { GestureRange:new{ ges = "hold", range = self.dimen } }
    }
end

-- Gestionnaire de clic
function CircleButton:onTapSelect()
    if self.callback then
        self.callback()
        return true
    end
    return false
end

-- Gestionnaire de maintien
function CircleButton:onHoldSelect()
    if self.hold_callback then
        self.hold_callback()
        return true
    end
    return false
end

-- Méthode pour changer l'état dynamiquement
function CircleButton:update_state(is_active)
    self.is_active = is_active
    self.circle.background = (self.is_active and not self.no_active_bg) and self.bg_active or self.bg_inactive
    UIManager:setDirty(self, "ui")
end

-- Lightweight live update of the text/number shown in the button (e.g. a
-- brightness value while dragging the slider), without rebuilding the whole
-- button (frame, borders, gestures...). Only works when the icon is plain
-- text (not an [icon=...] icon-font reference); returns false otherwise so
-- the caller can fall back to a full rebuild if needed.
function CircleButton:updateIcon(new_value)
    new_value = tostring(new_value or "")
    if not self.icon_widget or not self.icon_widget.setText then
        return false
    end
    self.icon = new_value
    self.icon_widget:setText(new_value)
    UIManager:setDirty(self, "ui")
    return true
end

return CircleButton
