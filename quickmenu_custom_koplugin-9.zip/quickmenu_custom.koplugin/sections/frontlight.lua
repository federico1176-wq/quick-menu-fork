local Button           = require("ui/widget/button")
local TextWidget       = require("ui/widget/textwidget")
local Font             = require("ui/font")
local VerticalGroup    = require("ui/widget/verticalgroup")
local VerticalSpan     = require("ui/widget/verticalspan")
local HorizontalGroup  = require("ui/widget/horizontalgroup")
local HorizontalSpan   = require("ui/widget/horizontalspan")
local ConfirmBox       = require("ui/widget/confirmbox")
local ButtonDialog    = require("ui/widget/buttondialog")

local Math             = require("optmath")

local UIManager        = require("ui/uimanager")

local IntensitySection = require("sections/intensitysection")
local IntensityZenUI   = require("sections/intensityzenui")
local WarmthSection    = require("sections/warmthsection")
local WarmthZenUI      = require("sections/warmthzenui")
local FrontlightToggle = require("sections/frontlight_toggle")

local Config           = require("config")
local Utils            = require("common/utils")
local _                = require("common/i18n").gettext

local Frontlight = {
    id = "frontlight",
    label = _("Frontlight"),
    icon  = "\u{EA2B}" -- led-on
}

-- ============================================================
-- Frontlight Builder
-- ============================================================
function Frontlight.build(ctx)
    -- ctx import
    local config             = ctx.config
    local touch_menu         = ctx.touch_menu
    local reader             = ctx.reader
    local filemanager        = ctx.filemanager
    local device             = ctx.device
    local powerd             = ctx.powerd
    local screen             = ctx.screen
    local datetime           = ctx.datetime
    local stat               = ctx.stat
    local panel_width        = ctx.panel_width
    local inner_width        = ctx.inner_width
    local h_gap              = screen:scaleBySize(config.style.h_gap or 4)
    local v_gap              = screen:scaleBySize(config.style.v_gap or 4)
    local btn_width          = screen:scaleBySize(config.style.btn_width or 50)
    local btn_radius         = screen:scaleBySize(config.style.btn_radius or 7)
    local btn_bordersize     = screen:scaleBySize(config.style.btn_bordersize or 1.5)
    local btn_font_size      = config.style.btn_font_size or 16
    local slider_ticks_width = screen:scaleBySize(config.style.slider_ticks_width or 1)

    local section = Utils.getSection(config, Frontlight.id)
    if not section then return nil end

    if filemanager and not section.enabled_f then return nil end

    if reader and not section.enabled_r then return nil end

    -- record value easy change for testing on emulator
    local hasFrontlight = not not device:hasFrontlight() -- force bool
    local hasNaturalLight = not not device:hasNaturalLight() -- force bool

    if not hasFrontlight then return nil end

    local refs = { buttons = {}, sliders = {}, widgets = {} }

    local group = VerticalGroup:new{ align = "center" }

    if section.use_zenslider then
        -- collapse, label_title, settings and slider
        local function settings_func() -- need to pass settings_func for settings_btn
            Frontlight.showSettings(ctx)
        end
        local intensityZenUI = IntensityZenUI.build(ctx, settings_func)
        table.insert(group, intensityZenUI.widget)
        table.insert(refs.sliders, intensityZenUI.refs.sliders[1])
        -- collapse break
        if section.collapse then return { widget = group , refs = refs} end
    else
        if section.show_title then
            local row_title = HorizontalGroup:new{ align = "center" }
            -- collapse
            local collapse_btn = Button:new{
                text           = section.collapse and "▶" or "▼",
                width          = btn_width,
                radius         = btn_radius,
                bordersize     = 0,
                text_font_size = btn_font_size,
                show_parent    = touch_menu.show_parent,
                callback       = function()
                    section.collapse = not section.collapse
                    Config.saveAndRefresh(ctx, true) -- no flush
                end,
                -- hold_callback
            }
            table.insert(row_title, collapse_btn)
            -- label
            local label = Frontlight.label .. " : " .. powerd:frontlightIntensity()
            if  hasNaturalLight and section.collapse then
                label = label .. " - " .._("Warmth") .. " : " .. powerd:frontlightWarmth() .. "%"
            end
            local label_title = TextWidget:new{
                text = label,
                face =  Font:getFace("cfont", btn_font_size), bold = true,
                max_width = inner_width - btn_width*2,
            }
            table.insert(row_title, label_title)
            table.insert(row_title, HorizontalSpan:new{ width = inner_width - label_title:getSize().w - btn_width*2 })
            -- settings
            local settings_btn = Button:new{
                text           = "\u{EB92}",
                width          = btn_width,
                radius         = btn_radius,
                bordersize     = 0,
                text_font_size = btn_font_size,
                show_parent    = touch_menu.show_parent,
                callback       = function()
                    Frontlight.showSettings(ctx)
                end,
                --hold_callback = function() end,
            }
            table.insert(row_title, settings_btn)
            --
            table.insert(group, row_title)
            -- collapse break
            if section.collapse then  return { widget = group , refs = refs} end
        end
        -- slider
        local toggle_result = section.show_toggle_buttons and FrontlightToggle.build(ctx) or nil
        local toggle_group = toggle_result and toggle_result.widget
        if toggle_group then
            local toggle_w = toggle_group:getSize().w

            local opts = {}
            for k, v in pairs(ctx) do opts[k] = v end
            opts.inner_width = inner_width - toggle_w - h_gap
            opts.match_height = toggle_group:getSize().h

            local light_btn = toggle_result.refs and toggle_result.refs.light_button
            local function onIntensityChange(v)
                if light_btn then light_btn:updateIcon(FrontlightToggle.formatLightValue(v)) end
            end

            local intensitySection = IntensitySection.build(opts, light_btn and onIntensityChange or nil)
            table.insert(refs.sliders, intensitySection.refs.sliders[1])

            local slider_row = HorizontalGroup:new{ align = "center" }
            if section.toggle_buttons_side == "right" then
                table.insert(slider_row, intensitySection.widget)
                table.insert(slider_row, HorizontalSpan:new{ width = h_gap })
                table.insert(slider_row, toggle_group)
            else
                table.insert(slider_row, toggle_group)
                table.insert(slider_row, HorizontalSpan:new{ width = h_gap })
                table.insert(slider_row, intensitySection.widget)
            end
            table.insert(group, Utils.attachSliderLabel(slider_row, section, btn_font_size))
        else
            local intensitySection = IntensitySection.build(ctx)
            table.insert(refs.sliders, intensitySection.refs.sliders[1])
            table.insert(group, Utils.attachSliderLabel(intensitySection.widget, section, btn_font_size))
        end
    end

    if hasNaturalLight then
        if section.use_zenslider then
            local warmthZenUI = WarmthZenUI.build(ctx)
            table.insert(group, warmthZenUI.widget)
            table.insert(refs.sliders, warmthZenUI.refs.sliders[1])
        else
            if section.show_title then
                local label_title = TextWidget:new{
                    text = _("Warmth") .. " : " .. powerd:frontlightWarmth() .. "%",
                    face =  Font:getFace("cfont", btn_font_size), bold = true,
                    max_width = inner_width,
                }
                local row_title = HorizontalGroup:new{
                align = "center",
                HorizontalSpan:new{ width = btn_width},
                label_title,
                HorizontalSpan:new{ width = inner_width - label_title:getSize().w -btn_width}
                }
                table.insert(group, row_title)
            else
                table.insert(group, VerticalSpan:new{ width = v_gap }) -- better for visual
            end
            local warmthSection = WarmthSection.build(ctx)
            table.insert(group, warmthSection.widget)
            table.insert(refs.sliders, warmthSection.refs.sliders[1])
        end
    end

    return { widget = group , refs = refs }
end

-- ============================================================
-- Settings Menu Builder
-- ============================================================
function Frontlight.getSettings(ctx, close, refresh, reload)
    -- ctx import
    local device  = ctx.device
    local config  = ctx.config
    local section = Utils.getSection(config, Frontlight.id)

    if not device:hasFrontlight() then return {} end
    if not section then return {} end

    return {
        {
            text = _("Enabled in filemanager"),
            checked_func = function() if reload then reload() end return section.enabled_f end,
            callback = function() section.enabled_f = not section.enabled_f; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Enabled in reader"),
            checked_func = function() if reload then reload() end return section.enabled_r end,
            callback = function() section.enabled_r = not section.enabled_r; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Show title"),
            checked_func = function() if reload then reload() end return section.show_title end,
            callback = function() section.show_title = not section.show_title; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Use ZenSlider"),
            checked_func = function() if reload then reload() end return section.use_zenslider end,
            callback = function() section.use_zenslider = not section.use_zenslider; Config.saveAndRefresh(ctx) end,
            help_text = _("Author : Anthony Gress\nProjet : Zen UI\nhttps://github.com/AnthonyGress/zen_ui.koplugin"),
        },
        {
            text_func = function()
                if reload then reload() end
                return _("Slider style") .. " : " .. Utils.getSliderStyleLabel(section.slider_style) .. "\xE2\x80\xA6"
            end,
            enabled_func = function() return section.use_zenslider end,
            keep_menu_open = true,
            callback = close(function()
                local items = {}
                for _, s in ipairs(Utils.getSliderStyles()) do
                    table.insert(items, {
                        text = s.label,
                        checked_func = function() return section.slider_style == s.id end,
                        radio = true,
                        callback = function() section.slider_style = s.id; Config.saveAndRefresh(ctx) end,
                    })
                end
                local MenuHost = require("actionchooser/menu_host")
                MenuHost.show{ title = _("Slider style"), item_table = items }
            end),
            help_text = _("Applies to both the Brightness and Warmth bars.\nPorted from neo_quicksetting's NeoSlider (Author: neo_quicksetting)."),
        },
        {
            text = _("Show light/night toggle buttons"),
            checked_func = function() if reload then reload() end return section.show_toggle_buttons end,
            callback = function() section.show_toggle_buttons = not section.show_toggle_buttons; Config.saveAndRefresh(ctx) end,
        },
        {
            text = _("Show toggle buttons labels"),
            checked_func = function() if reload then reload() end return section.show_toggle_labels end,
            enabled_func = function() return section.show_toggle_buttons end,
            callback = function() section.show_toggle_labels = not section.show_toggle_labels; Config.saveAndRefresh(ctx) end,
        },
        {
            text = _("Show label on brightness bar"),
            checked_func = function() if reload then reload() end return section.show_slider_label end,
            callback = function() section.show_slider_label = not section.show_slider_label; Config.saveAndRefresh(ctx) end,
        },
        {
            text_func = function()
                if reload then reload() end
                if section.toggle_buttons_side == "right" then return _("Toggle buttons position") .. " : " .. _("Right") end
                return _("Toggle buttons position") .. " : " .. _("Left")
            end,
            enabled_func = function() return section.show_toggle_buttons end,
            callback = function()
                section.toggle_buttons_side = (section.toggle_buttons_side == "right") and "left" or "right"
                Config.saveAndRefresh(ctx)
            end
        },
        {
            text_func = function()
                if reload then reload() end
                return _("Toggle buttons size") .. " (" .. tostring(config.style.toggle_action_size) .. ")\xE2\x80\xA6"
            end,
            enabled_func = function() return section.show_toggle_buttons end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = config.style.toggle_action_size
                local function getValue() return config.style.toggle_action_size end
                local function setValue(v) config.style.toggle_action_size = math.max(20, math.min(150, v)); Config.saveAndRefresh(ctx, true) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Toggle buttons size"),
                    buttons = {
                        {
                            { text = "-10", callback = function() nudge(-10) end },
                            { text = "-1",  callback = function() nudge(-1)  end },
                            { text_func = function() return tostring(getValue()) end, enabled = false },
                            { text = "+1",  callback = function() nudge(1)   end },
                            { text = "+10", callback = function() nudge(10)  end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.style.toggle_action_size); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local size = config.style.toggle_action_size or config.style.action_size or 64
                local v = config.style.toggle_action_radius
                if v == nil then v = size / 2 end
                local label
                if v <= 0 then
                    label = _("Square")
                elseif v >= size / 2 then
                    label = _("Circle")
                else
                    label = tostring(v)
                end
                return _("Toggle buttons shape") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            enabled_func = function() return section.show_toggle_buttons end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = config.style.toggle_action_radius
                local function getValue()
                    local v = config.style.toggle_action_radius
                    if v == nil then v = (config.style.toggle_action_size or config.style.action_size or 64) / 2 end
                    return v
                end
                local function setValue(v)
                    local max_radius = (config.style.toggle_action_size or config.style.action_size or 64) / 2
                    config.style.toggle_action_radius = math.max(0, math.min(max_radius, v))
                    Config.saveAndRefresh(ctx, true) -- no flush
                end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Toggle buttons shape") .. " (" .. _("0 = square") .. ")",
                    buttons = {
                        {
                            { text = "-10", callback = function() nudge(-10) end },
                            { text = "-1",  callback = function() nudge(-1)  end },
                            { text_func = function()
                                local size = config.style.toggle_action_size or config.style.action_size or 64
                                local v = getValue()
                                if v <= 0 then return _("Square") end
                                if v >= size / 2 then return _("Circle") end
                                return tostring(v)
                            end, enabled = false },
                            { text = "+1",  callback = function() nudge(1)   end },
                            { text = "+10", callback = function() nudge(10)  end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.style.toggle_action_radius); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.slider_btn_width
                local label = (not v or v == 0) and _("Default") or tostring(v)
                return _("Slider buttons width") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.slider_btn_width
                local function getValue() return section.slider_btn_width or 0 end
                local function setValue(v) section.slider_btn_width = math.max(0, math.min(200, v)); Config.saveAndRefresh(ctx, true) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Slider buttons width") .. " (" .. _("0 = default") .. ")",
                    buttons = {
                        {
                            { text = "-10", callback = function() nudge(-10) end },
                            { text = "-1",  callback = function() nudge(-1)  end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("Default") or tostring(v)
                            end, enabled = false },
                            { text = "+1",  callback = function() nudge(1)   end },
                            { text = "+10", callback = function() nudge(10)  end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.frontlight.slider_btn_width); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.slider_max_width
                local label = (not v or v == 0) and _("No limit") or tostring(v)
                return _("Slider max width") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.slider_max_width
                local function getValue() return section.slider_max_width or 0 end
                local function setValue(v) section.slider_max_width = math.max(0, math.min(3000, v)); Config.saveAndRefresh(ctx, true) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Slider max width") .. " (" .. _("0 = no limit") .. ")",
                    buttons = {
                        {
                            { text = "-50", callback = function() nudge(-50) end },
                            { text = "-10", callback = function() nudge(-10) end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("No limit") or tostring(v)
                            end, enabled = false },
                            { text = "+10", callback = function() nudge(10)  end },
                            { text = "+50", callback = function() nudge(50)  end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.frontlight.slider_max_width); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
        text = _("Reset section to defaults") .. "\xE2\x80\xA6",
        keep_menu_open = true,
        callback = close(function(touch_menu)
            if touch_menu then ctx.touch_menu = touch_menu end
            UIManager:show(ConfirmBox:new{
                text = _("Reset section to defaults") .. " ?",
                ok_text = _("Reset"),
                ok_callback = function()
                    local defaults = Config.DEFAULTS.sections[Frontlight.id]
                    Utils.resetSectionToDefaults(section, defaults)
                    Config.saveAndRefresh(ctx)
                    if refresh then refresh() end
                end,
                cancel_callback = function()
                    if refresh then refresh() end
                end,
            })
        end)
        }
    }
end

function Frontlight.showSettings(ctx)
    local dialog

    local function close(fn)
        return function()
            if dialog then UIManager:close(dialog) end
            if fn then fn() end
        end
    end

    local function refresh()
        Frontlight.showSettings(ctx)
    end
    -- use to refresh under check btn when dialog is transparent
    -- cost perf so block at openig as dialog never open transparent
    -- only from the dialog from the touch_menu itself it crash koreader
    local reload, activateReload = Utils.debouncedReload(ctx)

    local buttons = Utils.wrap_items(Frontlight.getSettings(ctx, close, refresh, reload))
    if not buttons or #buttons==0 then return end

    table.insert(buttons, {}) -- separator

    table.insert(buttons, {{
        text = _("Exit"),
        callback = close()
    }})

    dialog = ButtonDialog:new{
        -- dismissable = false,
        title = Frontlight.icon .. " " .. Frontlight.label .. " :",
        title_align  = "left",
        width_factor = 0.9,
        buttons = buttons,
    }
    UIManager:show(dialog)
    activateReload() -- allow reload after opening
end

return Frontlight
