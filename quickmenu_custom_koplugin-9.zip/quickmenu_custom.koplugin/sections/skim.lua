local ButtonDialog    = require("ui/widget/buttondialog")
local ConfirmBox      = require("ui/widget/confirmbox")

local UIManager       = require("ui/uimanager")

local Config          = require("config")
local ActionManage    = require("action_manage")
local Utils           = require("common/utils")
local _               = require("common/i18n").gettext

local Skim = {
    id = "skim",
    label = _("Skim grid"),
}

-- ============================================================
-- Settings Menu Builder
-- ============================================================
function Skim.getSettings(ctx, close, refresh, reload)
    local config  = ctx.config
    local section = Utils.getSection(config, Skim.id)
    if not section then return {} end

    local menu_items = {
        {
            text = _("Show labels"),
            checked_func = function() if reload then reload() end return section.show_label end,
            callback = function() section.show_label = not section.show_label; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Label inside icon box"),
            checked_func = function() if reload then reload() end return section.label_inside end,
            callback = function() section.label_inside = not section.label_inside; Config.saveAndRefresh(ctx) end
        },
        {
            text_func = function()
                local v = section.label_size
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Label size (icon mode)") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.label_size
                local function getValue() return section.label_size or 0 end
                local function setValue(v) section.label_size = math.max(0, math.min(40, v)); Config.saveAndRefresh(ctx) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta) setValue(getValue() + delta); dialog:reinit(); rebuild() end
                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Label size (icon mode)"),
                    buttons = {
                        {
                            { text = "-1", callback = function() nudge(-1) end },
                            { text_func = function() local v = getValue(); return v == 0 and _("Auto") or tostring(v) end, enabled = false },
                            { text = "+1", callback = function() nudge(1) end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.skim.label_size); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text = _("Rectangular buttons"),
            checked_func = function() if reload then reload() end return section.rect_ctrl end,
            callback = function() section.rect_ctrl = not section.rect_ctrl; Config.saveAndRefresh(ctx) end,
        },
        {
            text_func = function()
                local v = section.rect_height
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Row height (rect.)") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.rect_height
                local function getValue() return section.rect_height or 0 end
                local function setValue(v) section.rect_height = math.max(0, math.min(200, v)); Config.saveAndRefresh(ctx) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta) setValue(getValue() + delta); dialog:reinit(); rebuild() end
                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Row height (rect.)"),
                    buttons = {
                        {
                            { text = "-5", callback = function() nudge(-5) end },
                            { text_func = function() local v = getValue(); return v == 0 and _("Auto") or tostring(v) end, enabled = false },
                            { text = "+5", callback = function() nudge(5) end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.skim.rect_height); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text_func = function()
                local v = section.row_gap
                local label = (not v or v == 0) and _("Default") or tostring(v)
                return _("Row spacing") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.row_gap
                local function getValue() return section.row_gap or 0 end
                local function setValue(v) section.row_gap = math.max(0, math.min(60, v)); Config.saveAndRefresh(ctx) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta) setValue(getValue() + delta); dialog:reinit(); rebuild() end
                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Row spacing"),
                    buttons = {
                        {
                            { text = "-2", callback = function() nudge(-2) end },
                            { text_func = function() local v = getValue(); return v == 0 and _("Auto") or tostring(v) end, enabled = false },
                            { text = "+2", callback = function() nudge(2) end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.skim.row_gap); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text = _("Custom row pattern"),
            checked_func = function() if reload then reload() end return section.custom_rows end,
            callback = function() section.custom_rows = not section.custom_rows; Config.saveAndRefresh(ctx) end,
        },
        {
            text_func = function()
                local n = section.row_pattern and #section.row_pattern or 0
                return _("Icons/buttons per row") .. " (" .. n .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                Utils.showRowPatternEditor(ctx, Skim.id, refresh)
            end),
        },
        {
            text_func = function()
                local v = section.max_cols
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Columns (when not using pattern)") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.max_cols
                local function getValue() return section.max_cols or 0 end
                local function setValue(v) section.max_cols = math.max(0, math.min(15, v)); Config.saveAndRefresh(ctx) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta) setValue(getValue() + delta); dialog:reinit(); rebuild() end
                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Columns"),
                    buttons = {
                        {
                            { text = "-1", callback = function() nudge(-1) end },
                            { text_func = function() local v = getValue(); return v == 0 and _("Auto") or tostring(v) end, enabled = false },
                            { text = "+1", callback = function() nudge(1) end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.skim.max_cols); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
    }

    -- Select / sort / reset actions (reuses the same picker as Actions/
    -- Shortcuts, extended with the skim-only actions + "slider").
    local action_buttons = ActionManage:btnActionManageMenu(ctx, Skim.id, close, refresh)
    local flat_buttons = Utils.unwrap_items(action_buttons)
    for i, btn in ipairs(flat_buttons) do
        btn.keep_menu_open = true
        local original_callback = btn.callback
        btn.callback = function(touch_menu)
            if touch_menu then ctx.touch_menu = touch_menu end
            if original_callback then return original_callback() end
        end
        btn.separator = (i == #flat_buttons)
        table.insert(menu_items, btn)
    end

    table.insert(menu_items, {
        text = _("Reset section to defaults") .. "\xE2\x80\xA6",
        keep_menu_open = true,
        callback = close(function(touch_menu)
            if touch_menu then ctx.touch_menu = touch_menu end
            UIManager:show(ConfirmBox:new{
                text = _("Reset section to defaults") .. " ?",
                ok_text = _("Reset"),
                ok_callback = function()
                    local defaults = Config.DEFAULTS.sections[Skim.id]
                    Utils.resetSectionToDefaults(section, defaults)
                    Config.saveAndRefresh(ctx)
                    if refresh then refresh() end
                end,
                cancel_callback = function()
                    if refresh then refresh() end
                end,
            })
        end)
    })

    return menu_items
end

function Skim.showSettings(ctx)
    local dialog

    local function close(fn)
        return function()
            if dialog then UIManager:close(dialog) end
            if fn then fn() end
        end
    end

    local function refresh()
        Skim.showSettings(ctx)
    end

    local reload, activateReload = Utils.debouncedReload(ctx)

    local buttons = Utils.wrap_items(Skim.getSettings(ctx, close, refresh, reload))
    if not buttons or #buttons == 0 then return end

    table.insert(buttons, {}) -- separator
    table.insert(buttons, {{ text = _("Exit"), callback = close() }})

    dialog = ButtonDialog:new{
        title = _("Skim grid") .. " :",
        title_align  = "left",
        width_factor = 0.9,
        buttons = buttons,
        tap_close_callback = close()
    }
    UIManager:show(dialog)
    activateReload()
end

return Skim
