-- ============================================================
-- Índice (Table of Contents) section
-- ------------------------------------------------------------
-- Plain reflection of KOReader's own table of contents, shown as a
-- collapsible tree (like a folder/file browser): tap the ▶/▼ arrow to
-- expand or collapse a chapter's sub-chapters, tap the title to jump
-- straight to it. Paged with ‹ › buttons (no swiping), no boxes or
-- highlighted background on the rows -- just plain text inside a
-- thin outline.
-- ============================================================

local Blitbuffer      = require("ffi/blitbuffer")

local VerticalGroup    = require("ui/widget/verticalgroup")
local HorizontalGroup  = require("ui/widget/horizontalgroup")
local HorizontalSpan   = require("ui/widget/horizontalspan")
local VerticalSpan     = require("ui/widget/verticalspan")
local TextWidget       = require("ui/widget/textwidget")
local Button           = require("ui/widget/button")
local ButtonDialog     = require("ui/widget/buttondialog")
local ConfirmBox       = require("ui/widget/confirmbox")
local InfoMessage      = require("ui/widget/infomessage")
local FrameContainer   = require("ui/widget/container/framecontainer")

local Font             = require("ui/font")
local Event            = require("ui/event")
local UIManager         = require("ui/uimanager")

local Config           = require("config")
local ClickableGroup   = require("widgets/clickablegroup")
local ShadowDeco       = require("widgets/shadow_deco")
local Utils            = require("common/utils")
local _                = require("common/i18n").gettext
local logger           = require("logger")

local DEBUG = false -- ponelo en true para loguear qué fuente de datos se usó

local Toc = {
    id = "toc",
    label = _("Índice"),
    icon  = "\u{F0C9}", -- same glyph already used for the "show ToC" button in skim

    -- Ephemeral state (module-level, not saved to disk):
    -- which chapters are expanded (open) in the tree, keyed by the
    -- ToC entry's own table identity (weak so it never leaks memory
    -- when a book is closed).
    expanded = setmetatable({}, { __mode = "k" }),
    -- file path of the book we last auto-expanded/paged for, so we
    -- only do that once per book, not on every rebuild.
    _seeded_file = nil,
    -- true right after opening a book, or after tapping "go to current
    -- chapter": next build should expand the path down to it and jump
    -- to the page that contains it.
    _pending_jump = true,
    -- current page (0-based) within the visible (post-expand) list
    _page_idx = 0,
}

-- ============================================================
-- Read KOReader's own table of contents, defensively: different
-- KOReader releases expose it under slightly different method
-- names, so try the known ones in order and fall back gracefully
-- instead of crashing if none is available.
-- ============================================================
function Toc.getFlatToc(reader)
    local toc_mod = reader and reader.toc
    if not toc_mod then return nil end

    -- A valid chapter list is a table of tables (each with at least a
    -- .page); reject tables of plain numbers, which is what the *ticks*
    -- APIs return (progress-bar positions, not chapters).
    local function isStructured(result)
        return type(result) == "table" and #result > 0 and type(result[1]) == "table"
    end

    local function tryCall(name, ...)
        local fn = toc_mod[name]
        if type(fn) ~= "function" then return nil end
        local ok, result = pcall(fn, toc_mod, ...)
        if ok and isStructured(result) then return result end
        return nil
    end

    -- toc_mod.toc is KOReader's own parsed table of contents (the same
    -- data its native ToC screen renders from) -- try it first.
    -- getFullToc() only exists on some KOReader versions. Deliberately
    -- NOT trying getTocTicksFlattened()/getTocTicks(): those return
    -- flat arrays of page numbers for the progress bar, not chapters.
    local toc, source = nil, nil
    if isStructured(toc_mod.toc) then
        toc, source = toc_mod.toc, "toc_mod.toc"
    else
        toc, source = tryCall("getFullToc"), "getFullToc()"
    end

    if DEBUG then
        logger.dbg("[quickmenu toc]", toc and ("usando " .. source .. ", " .. #toc .. " entradas") or "sin datos de índice estructurados")
    end

    return toc
end

-- KOReader's internal ToC entries use "title" as the field name; some
-- code paths (its own ToC menu widget) copy that into "text" when
-- building menu items. Accept either so we work across versions.
local function tocEntryTitle(item)
    return item.text or item.title
end

-- ============================================================
-- Chapter length (pages) + estimated reading time, ported from the
-- "toc-reading-time" patch: same data source (ReaderToc's own
-- chapter-length calculation + the Statistics plugin), just read
-- into a side table instead of mutated into the native ToC fields,
-- so it never touches KOReader's own ToC screen/state.
-- Keyed by item table identity: entries are shared references to
-- ReaderToc's own toc array (see Toc.getFlatToc above), so this
-- survives across our own filtering/pagination without recomputing.
-- ============================================================
local chapter_stats = setmetatable({}, { __mode = "k" })

-- Ask ReaderToc to (re)compute item.chapter_length for every entry.
-- Cheap to call repeatedly: KOReader only redoes the work when the
-- toc/page count actually changed. Defensive: different KOReader
-- versions expose one or the other (or, on some old builds, neither).
local function ensureChapterLengths(reader)
    local toc_mod = reader and reader.toc
    if not toc_mod then return end
    if type(toc_mod.completeTocWithChapterLengths) == "function" then
        pcall(toc_mod.completeTocWithChapterLengths, toc_mod)
    end
    if type(toc_mod.completeTocWithChapterLengthsFromPagemap) == "function" then
        pcall(toc_mod.completeTocWithChapterLengthsFromPagemap, toc_mod)
    end
end

-- Extract a plain page-count number from chapter_length. Defensive:
-- if another installed patch (e.g. the community "toc-reading-time"
-- one) already hooked the same native function and turned this field
-- into a "N | mm:ss" string, pull the leading number back out instead
-- of crashing on a string/number comparison.
local function toChapterLength(raw)
    if type(raw) == "number" then
        return raw > 0 and raw or nil
    end
    if type(raw) == "string" then
        local n = tonumber(raw:match("^%s*(%d+)"))
        if n and n > 0 then return n end
    end
    return nil
end

-- Pages-in-chapter + formatted time string for one entry, mirroring
-- the patch's injectTime(): prefer the *remaining* pages from the
-- reader's current position for the chapter currently being read
-- (no sub-chapters in between), else fall back to its full length.
local function computeChapterStat(reader, item, next_item)
    if type(item) ~= "table" then return nil end
    local toc_mod = reader.toc
    local stats   = reader.statistics
    if not toc_mod or not stats then return nil end

    local chapter_length = toChapterLength(item.chapter_length)
    if not chapter_length then return nil end

    local has_children = type(next_item) == "table" and next_item.depth and item.depth
        and next_item.depth > item.depth

    local pages_for_time
    if not has_children and item.page and type(toc_mod.getChapterPagesLeft) == "function" then
        local ok, left = pcall(toc_mod.getChapterPagesLeft, toc_mod, item.page, true)
        if ok and type(left) == "number" then pages_for_time = left end
    end
    if not pages_for_time or pages_for_time <= 0 then
        pages_for_time = chapter_length
    end

    local time_str
    local ok_t, result = pcall(stats.getTimeForPages, stats, pages_for_time)
    if ok_t and type(result) == "string" and result ~= "" then time_str = result end

    return { pages = chapter_length, time = time_str }
end

-- Populate chapter_stats for every entry in the *unfiltered* toc, so
-- "has children" is judged against the real hierarchy. Guards against
-- non-table entries; the caller also wraps this in a pcall so a bad
-- entry never takes down the whole section.
local function collectChapterStats(reader, toc_items)
    ensureChapterLengths(reader)
    for i, item in ipairs(toc_items) do
        if type(item) == "table" then
            chapter_stats[item] = computeChapterStat(reader, item, toc_items[i + 1])
        end
    end
end

-- ============================================================
-- Tree helpers
-- ============================================================

-- current chapter = last raw entry whose page is <= current page
local function findActiveIndex(toc_items, current_page)
    local active_index = 1
    for i, item in ipairs(toc_items) do
        if (item.page or 0) <= current_page then active_index = i else break end
    end
    return active_index
end

-- Opens every ancestor of toc_items[active_index] so the current
-- chapter is reachable without the user having to expand anything.
local function expandAncestors(toc_items, active_index)
    local active = toc_items[active_index]
    if not active then return end
    local min_depth = math.max(1, active.depth or 1)
    for i = active_index - 1, 1, -1 do
        local d = math.max(1, toc_items[i].depth or 1)
        if d < min_depth then
            Toc.expanded[toc_items[i]] = true
            min_depth = d
            if min_depth <= 1 then break end
        end
    end
end

-- Flattens toc_items into the currently *visible* rows: a chapter's
-- children are only included while it is expanded (and within
-- max_depth, if capped). Returns a list of { item, depth, has_children }.
local function buildVisibleList(toc_items, max_depth)
    local visible = {}
    local hide_below_depth = nil -- while set, skip anything deeper than this
    for i, item in ipairs(toc_items) do
        local depth = math.max(1, item.depth or 1)
        if max_depth > 0 and depth > max_depth then
            -- beyond the allowed depth entirely: skip, don't touch collapse tracking
        elseif hide_below_depth and depth > hide_below_depth then
            -- descendant of a collapsed (or depth-capped) ancestor: skip
        else
            hide_below_depth = nil
            local next_item = toc_items[i + 1]
            local next_depth = next_item and math.max(1, next_item.depth or 1)
            local has_children = next_depth ~= nil and next_depth > depth
                and (max_depth == 0 or next_depth <= max_depth)
            table.insert(visible, { item = item, depth = depth, has_children = has_children })
            if has_children and not Toc.expanded[item] then
                hide_below_depth = depth
            end
        end
    end
    return visible
end

-- ============================================================
-- Builder
-- ============================================================
function Toc.build(ctx)
    -- ctx import
    local config       = ctx.config
    local touch_menu   = ctx.touch_menu
    local reader       = ctx.reader
    local screen       = ctx.screen
    local inner_width  = ctx.inner_width
    local h_gap        = screen:scaleBySize(config.style.h_gap or 4)
    local v_gap        = screen:scaleBySize(config.style.v_gap or 4)
    local btn_width    = screen:scaleBySize(config.style.btn_width or 50)
    local btn_radius   = screen:scaleBySize(config.style.btn_radius or 7)
    local btn_font_size = config.style.btn_font_size or 16

    local section = Utils.getSection(config, Toc.id)
    if not section or not section.enabled_r then return nil end
    if not reader or not reader.document then return nil end -- reader-only, needs an open book

    -- New book opened since last render? Re-seed: expand the path to
    -- the current chapter and jump to the page that contains it.
    local doc_file = reader.document.file
    if Toc._seeded_file ~= doc_file then
        Toc._seeded_file = doc_file
        Toc._pending_jump = true
        Toc._page_idx = 0
    end

    local refs = { buttons = {}, sliders = {}, widgets = {} }
    local group = VerticalGroup:new{ align = "center" }

    local current_page = reader:getCurrentPage()

    -- ------------------------------------------------------------
    -- Title row (collapse toggle + label + go-to-current + fullscreen
    -- + settings), same pattern as the other collapsible sections
    -- (see sections/info.lua)
    -- ------------------------------------------------------------
    if section.show_title then
        local collapse_btn = Button:new{
            text           = section.collapse and "▶" or "▼",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                section.collapse = not section.collapse
                Config.saveAndRefresh(ctx, true)
            end,
        }

        local label_info = ""
        if section.collapse then
            local ok, title = pcall(function() return reader.toc:getTocTitleByPage(current_page) end)
            if ok and title then label_info = title end
        end

        local label_title = TextWidget:new{
            text = Toc.label .. (label_info ~= "" and (" : " .. label_info) or ""),
            face = Font:getFace("cfont", btn_font_size),
            bold = true,
            max_width = inner_width - btn_width * 4,
        }

        -- Re-open the path to the current chapter and scroll to it
        -- (handy once you've collapsed/scrolled away navigating).
        local current_btn = Button:new{
            text           = "\u{F015}",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                Toc._pending_jump = true
                Config.saveAndRefresh(ctx, true)
            end,
        }

        -- Open KOReader's own full-screen ToC screen, for when the
        -- compact panel isn't enough (full titles, native search, etc.)
        local fullscreen_btn = Button:new{
            text           = "\u{F065}",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                touch_menu:closeMenu()
                local ok = false
                if reader.toc and type(reader.toc.onShowToc) == "function" then
                    ok = pcall(function() reader.toc:onShowToc() end)
                end
                if not ok then
                    pcall(function() reader:handleEvent(Event:new("ShowToc")) end)
                end
            end,
        }

        local settings_btn = Button:new{
            text           = "\u{EB92}",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function() Toc.showSettings(ctx) end,
        }

        table.insert(group, HorizontalGroup:new{
            align = "center",
            collapse_btn,
            label_title,
            HorizontalSpan:new{ width = inner_width - label_title:getSize().w - btn_width * 4 },
            current_btn,
            fullscreen_btn,
            settings_btn,
        })

        if section.collapse then return { widget = group, refs = refs } end
    end

    -- ------------------------------------------------------------
    -- Rows: a plain, swipeable tree -- no boxes, no highlighted
    -- background, no page-flip buttons.
    -- ------------------------------------------------------------
    local toc_items = Toc.getFlatToc(reader)

    if not toc_items or #toc_items == 0 then
        table.insert(group, VerticalSpan:new{ width = v_gap })
        table.insert(group, TextWidget:new{
            text = _("No index available for this book."),
            face = Font:getFace("cfont", math.max(btn_font_size - 2, 10)),
            max_width = inner_width,
        })
        return { widget = group, refs = refs }
    end

    local active_index = findActiveIndex(toc_items, current_page)
    if Toc._pending_jump then
        expandAncestors(toc_items, active_index)
    end

    local max_depth = section.max_depth or 0 -- 0 = no cap on how deep you can expand
    local visible = buildVisibleList(toc_items, max_depth)

    if #visible == 0 then
        table.insert(group, TextWidget:new{
            text = _("No index available for this book."),
            face = Font:getFace("cfont", math.max(btn_font_size - 2, 10)),
            max_width = inner_width,
        })
        return { widget = group, refs = refs }
    end

    -- ------------------------------------------------------------
    -- Pagination over the *visible* (post expand/collapse) list --
    -- plain ‹ page X/Y › buttons, no swiping.
    -- ------------------------------------------------------------
    local rows_per_page = (section.max_visible_rows and section.max_visible_rows > 0)
        and section.max_visible_rows or #visible
    local total_pages = math.max(1, math.ceil(#visible / rows_per_page))

    local active_visible_idx = nil
    for i, entry in ipairs(visible) do
        if entry.item == toc_items[active_index] then active_visible_idx = i break end
    end
    local auto_page = active_visible_idx and math.floor((active_visible_idx - 1) / rows_per_page) or 0

    if Toc._pending_jump then
        Toc._page_idx = auto_page
    end
    Toc._pending_jump = false
    local page_idx = math.max(0, math.min(total_pages - 1, Toc._page_idx or 0))
    Toc._page_idx = page_idx

    local start_i = page_idx * rows_per_page + 1
    local end_i    = math.min(start_i + rows_per_page - 1, #visible)

    local indent_step = screen:scaleBySize(section.indent_size or 14)
    local row_font_size = (section.row_font_size and section.row_font_size > 0) and section.row_font_size or btn_font_size
    local face      = Font:getFace("cfont", row_font_size)
    local page_face = Font:getFace("cfont", math.max(row_font_size - 3, 10))
    local meta_face = Font:getFace("cfont", math.max(row_font_size - 4, 9))
    local page_col_w = section.show_page_numbers and screen:scaleBySize(34) or 0
    local chevron_w = screen:scaleBySize(22)

    -- content area minus the box's own padding+border, so the whole
    -- frame (box_pad + border + content + border + box_pad) stays
    -- exactly inner_width wide, never overflowing the panel
    local box_pad    = h_gap
    local box_border = screen:scaleBySize(config.style.btn_bordersize or 1.5)
    local content_w  = inner_width - 2 * (box_pad + box_border)

    local want_stats = (section.show_chapter_pages or section.show_chapter_time) and reader.statistics ~= nil
    if want_stats then
        local ok = pcall(collectChapterStats, reader, toc_items)
        if not ok then want_stats = false end
    end

    -- Builds one plain row: [indent][▶/▼ or blank][title][page] and,
    -- optionally, a small second line with the chapter's page count
    -- and/or estimated reading time.
    local function buildRow(entry)
        local item, depth, has_children = entry.item, entry.depth, entry.has_children
        local is_active = (item == toc_items[active_index])
        local indent_w = indent_step * math.min(depth - 1, 6)
        local full_title = tocEntryTitle(item) or _("Untitled")

        local chevron
        if has_children then
            chevron = Button:new{
                text           = Toc.expanded[item] and "▼" or "▶",
                width          = chevron_w,
                radius         = 0,
                bordersize     = 0,
                text_font_size = math.max(row_font_size - 3, 10),
                show_parent    = touch_menu.show_parent,
                callback       = function()
                    Toc.expanded[item] = not Toc.expanded[item]
                    Config.saveAndRefresh(ctx, true)
                end,
            }
        else
            chevron = HorizontalSpan:new{ width = chevron_w }
        end

        local title_w = content_w - 4 * h_gap - indent_w - chevron_w - page_col_w
        local title_txt = TextWidget:new{
            text = full_title,
            face = face,
            bold = is_active,
            max_width = math.max(title_w, screen:scaleBySize(20)),
        }

        local title_row = HorizontalGroup:new{ align = "center" }
        table.insert(title_row, title_txt)
        if section.show_page_numbers and item.page then
            table.insert(title_row, HorizontalSpan:new{ width = math.max(0, title_w - title_txt:getSize().w) })
            table.insert(title_row, TextWidget:new{ text = tostring(item.page), face = page_face })
        end

        -- plain, no background/shadow: "sin efectos"
        local title_click = ClickableGroup:new{
            title_row,
            padding    = 0,
            bordersize = 0,
            callback = function()
                if not item.page then return end
                reader.link:addCurrentLocationToStack()
                reader:handleEvent(Event:new("GotoPage", item.page))
                touch_menu:closeMenu()
            end,
            hold_callback = function()
                -- Full title, in case it got truncated to fit the panel
                UIManager:show(InfoMessage:new{ show_icon = false, text = full_title })
            end,
        }

        local row = HorizontalGroup:new{
            align = "center",
            HorizontalSpan:new{ width = indent_w },
            chevron,
            title_click,
        }
        local col = VerticalGroup:new{ align = "left", row }

        -- Second, smaller line: "N p | mm:ss", ported from the
        -- toc-reading-time patch (chapter length + estimated time).
        if want_stats then
            local stat = chapter_stats[item]
            if stat then
                local parts = {}
                if section.show_chapter_pages and stat.pages then
                    table.insert(parts, tostring(stat.pages) .. "p")
                end
                if section.show_chapter_time and stat.time then
                    table.insert(parts, stat.time)
                end
                if #parts > 0 then
                    table.insert(col, HorizontalGroup:new{
                        align = "center",
                        HorizontalSpan:new{ width = indent_w + chevron_w },
                        TextWidget:new{
                            text = table.concat(parts, "  |  "),
                            face = meta_face,
                            fgcolor = Blitbuffer.COLOR_BLACK,
                            max_width = math.max(content_w - 4 * h_gap - indent_w - chevron_w, screen:scaleBySize(20)),
                        },
                    })
                end
            end
        end

        return col
    end

    local rows_col = VerticalGroup:new{ align = "left" }
    for i = start_i, end_i do
        table.insert(rows_col, buildRow(visible[i]))
    end

    -- ------------------------------------------------------------
    -- Pagination row: ⌂ (go to current chapter) ‹ page X/Y ›
    -- ------------------------------------------------------------
    local content_widget = rows_col
    if total_pages > 1 then
        local prev_btn = Button:new{
            text           = "‹",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            enabled        = page_idx > 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                Toc._page_idx = math.max(0, page_idx - 1)
                Config.saveAndRefresh(ctx, true)
            end,
        }
        local next_btn = Button:new{
            text           = "›",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            enabled        = page_idx < total_pages - 1,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                Toc._page_idx = math.min(total_pages - 1, page_idx + 1)
                Config.saveAndRefresh(ctx, true)
            end,
        }
        local page_label = TextWidget:new{
            text = tostring(page_idx + 1) .. " / " .. tostring(total_pages),
            face = Font:getFace("cfont", math.max(btn_font_size - 1, 10)),
        }
        local side_w = math.max(0, (content_w - 2 * h_gap - prev_btn:getSize().w - next_btn:getSize().w - page_label:getSize().w) / 2)
        local nav_row = HorizontalGroup:new{
            align = "center",
            prev_btn,
            HorizontalSpan:new{ width = side_w },
            page_label,
            HorizontalSpan:new{ width = side_w },
            next_btn,
        }
        content_widget = VerticalGroup:new{ align = "center", rows_col, VerticalSpan:new{ width = v_gap }, nav_row }
    end

    -- Contain the whole tree inside a bordered box, with the same
    -- drop-shadow used by the rest of the panel's elements. Sized to
    -- exactly inner_width so it never overflows the panel.
    local box = FrameContainer:new{
        padding    = box_pad,
        radius     = btn_radius,
        bordersize = box_border,
        background = Blitbuffer.COLOR_WHITE,
        content_widget,
    }
    ShadowDeco.attach(box)

    table.insert(group, box)
    return { widget = group, refs = refs }
end

-- ============================================================
-- Settings
-- ============================================================
function Toc.getSettings(ctx, close, refresh, reload)
    local config  = ctx.config
    local section = Utils.getSection(config, Toc.id)
    if not section then return {} end

    local function nudgeDialog(title, getValue, setValue, default, min, max, formatValue, step)
        local dialog
        local original = getValue()
        local function rebuild() Config.saveAndRefresh(ctx, true) end
        local function nudge(delta)
            setValue(math.max(min, math.min(max, getValue() + delta)))
            rebuild()
            dialog:reinit()
        end
        local function closeDialog() UIManager:close(dialog); if refresh then refresh() end end
        local function revert() setValue(original); rebuild() end
        step = step or 1

        dialog = ButtonDialog:new{
            dismissable = false,
            title = title,
            buttons = {
                {
                    { text = "-" .. step, callback = function() nudge(-step) end },
                    { text_func = function() return formatValue(getValue()) end, enabled = false },
                    { text = "+" .. step, callback = function() nudge(step) end },
                },
                {
                    { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                    { text = _("Default"), callback = function() setValue(default); rebuild(); dialog:reinit() end },
                    { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                },
            },
            tap_close_callback = revert,
        }
        UIManager:show(dialog)
    end

    return {
        {
            text = _("Enabled in reader"),
            checked_func = function() if reload then reload() end return section.enabled_r end,
            callback = function() section.enabled_r = not section.enabled_r; Config.saveAndRefresh(ctx) end,
        },
        {
            text = _("Show section title"),
            checked_func = function() return section.show_title end,
            callback = function()
                section.show_title = not section.show_title
                Config.saveAndRefresh(ctx)
                if refresh then refresh() end
            end,
        },
        {
            text = _("Show page numbers"),
            checked_func = function() return section.show_page_numbers end,
            callback = function()
                section.show_page_numbers = not section.show_page_numbers
                Config.saveAndRefresh(ctx)
                if refresh then refresh() end
            end,
        },
        {
            text = _("Show chapter page count"),
            help_text = _("Shows how many pages each chapter has, right under its title. Requires KOReader's native 'Show chapter length' (ToC settings) to be enabled."),
            checked_func = function() return section.show_chapter_pages end,
            callback = function()
                section.show_chapter_pages = not section.show_chapter_pages
                Config.saveAndRefresh(ctx)
                if refresh then refresh() end
            end,
        },
        {
            text = _("Show chapter reading time"),
            help_text = _("Shows the estimated reading time for each chapter, based on your reading statistics. Requires the Statistics plugin to be enabled."),
            checked_func = function() return section.show_chapter_time end,
            callback = function()
                section.show_chapter_time = not section.show_chapter_time
                Config.saveAndRefresh(ctx)
                if refresh then refresh() end
            end,
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.max_visible_rows or 0
                return _("Rows per page") .. " (" .. (v == 0 and _("No limit") or tostring(v)) .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                nudgeDialog(
                    _("Rows per page") .. " (" .. _("0 = no limit, no paging") .. ")",
                    function() return section.max_visible_rows or 0 end,
                    function(v) section.max_visible_rows = v end,
                    Config.DEFAULTS.sections.toc.max_visible_rows, 0, 30,
                    function(v) return v == 0 and _("No limit") or tostring(v) end
                )
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.row_font_size or 0
                return _("Font size") .. " (" .. (v == 0 and _("Default") or tostring(v)) .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                nudgeDialog(
                    _("Font size") .. " (" .. _("0 = default, follows the panel's own font size") .. ")",
                    function() return section.row_font_size or 0 end,
                    function(v) section.row_font_size = v end,
                    Config.DEFAULTS.sections.toc.row_font_size, 0, 30,
                    function(v) return v == 0 and _("Default") or tostring(v) end
                )
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.max_depth or 0
                return _("Max. expandable depth") .. " (" .. (v == 0 and _("No limit") or tostring(v)) .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                nudgeDialog(
                    _("Max. expandable depth") .. " (" .. _("0 = no limit") .. ")",
                    function() return section.max_depth or 0 end,
                    function(v) section.max_depth = v end,
                    Config.DEFAULTS.sections.toc.max_depth, 0, 8,
                    function(v) return v == 0 and _("No limit") or tostring(v) end
                )
            end),
        },
        {
            text = _("Reset section to defaults") .. "\xE2\x80\xA6",
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                UIManager:show(ConfirmBox:new{
                    text = _("Reset section to defaults") .. " ?",
                    ok_text = _("Reset"),
                    ok_callback = function()
                        Utils.resetSectionToDefaults(section, Config.DEFAULTS.sections[Toc.id])
                        Config.saveAndRefresh(ctx)
                        if refresh then refresh() end
                    end,
                    cancel_callback = function() if refresh then refresh() end end,
                })
            end),
        },
    }
end

function Toc.showSettings(ctx)
    local dialog
    local function close(fn)
        return function()
            if dialog then UIManager:close(dialog) end
            if fn then fn() end
        end
    end
    local function refresh() Toc.showSettings(ctx) end
    local reload, activateReload = Utils.debouncedReload(ctx)

    local buttons = Utils.wrap_items(Toc.getSettings(ctx, close, refresh, reload))
    if not buttons or #buttons == 0 then return end

    table.insert(buttons, {})
    table.insert(buttons, {{ text = _("Exit"), callback = close() }})

    dialog = ButtonDialog:new{
        title = Toc.icon .. " " .. Toc.label .. " :",
        title_align = "left",
        width_factor = 0.9,
        buttons = buttons,
    }
    UIManager:show(dialog)
    activateReload()
end

return Toc
