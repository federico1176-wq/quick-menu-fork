local Button          = require("ui/widget/button")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local TextWidget      = require("ui/widget/textwidget")
local ConfirmBox       = require("ui/widget/confirmbox")
local ButtonDialog    = require("ui/widget/buttondialog")

local Font            = require("ui/font")
local FontList        = require("fontlist")
local RenderImage     = require("ui/renderimage")
local Math            = require("optmath")
local UIManager       = require("ui/uimanager")

local Config          = require("config")
local InfoSection     = require("sections/infosection")
local SkimSection     = require("sections/skimsection")
local CoverButton     = require("widgets/coverbutton")
local VScrollGroup    = require("widgets/vscrollgroup")
local ActionChooser   = require("actionchooser/action_chooser")
local Utils           = require("common/utils")
local _               = require("common/i18n").gettext

local Info = {
    id = "info",
    label = _("Reading"),
    icon  = "\u{E7BA}" --book-multiple
}

-- Basename (e.g. "NotoSans-Regular.ttf") of a font file path, and its
-- human-readable display name if KOReader's font list has metadata for it.
local function fontBasename(font_path)
    return font_path:match("([^/]+)$") or font_path
end
local function fontDisplayName(font_path)
    local info = FontList.fontinfo and FontList.fontinfo[font_path]
    if info and info[1] and info[1].name then return info[1].name end
    return fontBasename(font_path)
end

-- ============================================================
-- Info Builder
-- ============================================================
function Info.build(ctx)
    -- ctx import
    local config             = ctx.config
    local touch_menu         = ctx.touch_menu
    local reader             = ctx.reader
    local filemanager        = ctx.filemanager
    local device             = ctx.device
    local powerd             = ctx.powerd
    local screen             = ctx.screen
    local datetime           = ctx.datetime
    local stat               = ctx.stat
    local panel_width        = ctx.panel_width
    local inner_width        = ctx.inner_width
    local h_gap              = screen:scaleBySize(config.style.h_gap or 4)
    local v_gap              = screen:scaleBySize(config.style.v_gap or 4)
    local btn_width          = screen:scaleBySize(config.style.btn_width or 50)
    local btn_radius         = screen:scaleBySize(config.style.btn_radius or 7)
    local btn_bordersize     = screen:scaleBySize(config.style.btn_bordersize or 1.5)
    local btn_font_size      = config.style.btn_font_size or 16
    local slider_ticks_width = screen:scaleBySize(config.style.slider_ticks_width or 1)

    local section      = Utils.getSection(config, Info.id)

    if not section or not section.enabled_r or not reader then return nil end
    local refs = { buttons = {}, sliders = {}, widgets = {} }

    local group = VerticalGroup:new{ align = "center" }

    if section.show_title then
        -- collapse
        local collapse_btn = Button:new{
            text           = section.collapse and "▶" or "▼",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                section.collapse = not section.collapse
                Config.saveAndRefresh(ctx, true) -- no flush
            end,
            --hold_callback = function() end,
        }
        -- add info near section name when collapse
        local label_info = ""
        if section.collapse then
            local percent_read = ""
            local title = ""
            if reader then
                local current_page = reader:getCurrentPage()
                if reader.document then
                    local total_page = reader.document:getPageCount()
                    if type(total_page) == "number" and total_page > 0 then  percent_read = Math.round(100 * (current_page or 0) / total_page) .. "%"  end
                end
                title = (reader.doc_props and reader.doc_props.display_title) or (reader.props and reader.props.title) or ""
            end
            if percent_read ~= "" and title ~= "" then  label_info = string.format(_("%s of %s"), percent_read, title)
            elseif title ~= "" then  label_info = title
            else label_info = "" end
        end
        -- section name
        local label_title = TextWidget:new{
            text = Info.label .. " : " .. label_info,
            face =  Font:getFace("cfont", btn_font_size), bold = true,
            max_width = inner_width - btn_width*2,
        }
        -- settings
        local settings_btn = Button:new{
            text           = "\u{EB92}",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                Info.showSettings(ctx)
            end,
            --hold_callback = function() end,
        }
        --
        local row_title = HorizontalGroup:new{
            align = "center",
            collapse_btn,
            label_title,
            HorizontalSpan:new{ width = inner_width - label_title:getSize().w - btn_width*2 },
            settings_btn,
        }
        table.insert(group, row_title)
        -- stop render if section is collapse
        if section.collapse then  return { widget = group , refs = refs} end
    end

    local info_col = VerticalGroup:new{ align = "center" }
    local infoSection = InfoSection.build(ctx)
    if infoSection and infoSection.widget then
        table.insert(info_col, infoSection.widget)
    end

    if section.show_skim then
        local skimSection = SkimSection.build(ctx)
        table.insert(info_col, VerticalSpan:new{ width = v_gap })
        table.insert(info_col, skimSection.widget)
        table.insert(refs.sliders, skimSection.refs.sliders[1])
    end

    --
    local row = HorizontalGroup:new{ align = "center" }

    if section.show_thumbnail then -- TODO more test
        local cover_h = info_col:getSize().h
        local cover_w = math.floor(2 * cover_h / 3 + 0.5)

        local opts = {}
        for k, v in pairs(ctx) do opts[k] = v end
        opts.inner_width = inner_width - cover_w - 2 * h_gap

        local new_info_col = VerticalGroup:new{ align = "left" }
        local new_infoSection = InfoSection.build(opts)
        if new_infoSection and new_infoSection.widget then
            table.insert(new_info_col, new_infoSection.widget)
        end

        local skimSection
        if section.show_skim then
            skimSection = SkimSection.build(opts)
            table.insert(new_info_col, VerticalSpan:new{ width = v_gap })
            table.insert(new_info_col, skimSection.widget)
        end

        local use_preview = section.thumbnail_mode == "preview"
        local ok, thumbnail

        if use_preview then
            local preview_page = (skimSection and skimSection.getPreviewPage and skimSection.getPreviewPage())
                or reader:getCurrentPage()
            thumbnail = Utils.renderPagePreview(reader.document, preview_page, cover_w, cover_h)
            ok = thumbnail ~= nil
        else
            ok, thumbnail = pcall(function() return reader.bookinfo:getCoverImage(reader.document) end)
            if ok then
                ok, thumbnail = pcall(function() return RenderImage:scaleBlitBuffer(thumbnail, cover_w, cover_h, true) end)
            end
        end

        if ok and thumbnail then
            info_col = new_info_col
            if skimSection then table.insert(refs.sliders, skimSection.refs.sliders[1]) end

            local info_thumbnail = CoverButton:new{
                image = thumbnail,
                width = cover_w,
                height = cover_h,
                radius = btn_radius,
                bordersize = btn_bordersize,
                padding = 0, --h_gap,
                callback = function()
                    if use_preview then
                        touch_menu:closeMenu()
                        if skimSection and skimSection.commitPreview then skimSection.commitPreview() end
                    else
                        touch_menu:closeMenu()
                        reader.bookinfo:onShowBookCover(reader.document.file)
                    end
                end,
                hold_callback = function()
                    if use_preview then
                        if skimSection and skimSection.resetPreview then skimSection.resetPreview() end
                        if touch_menu and touch_menu.updateItems then touch_menu:updateItems(1) end
                    else
                        touch_menu:closeMenu()
                        reader.bookinfo:onShowBookDescription(false, reader.document.file)
                    end
                end
            }

            if section.cover_side == "right" then
                table.insert(row, info_col)
                table.insert(row, HorizontalSpan:new{ width = h_gap })
                table.insert(row, info_thumbnail)
            else
                table.insert(row, info_thumbnail)
                table.insert(row, HorizontalSpan:new{ width = h_gap })
                table.insert(row, info_col)
            end
        end
    end

    if #row == 0 then
        table.insert(row, info_col)
    end

    local content_widget = row
    if section.section_height and section.section_height > 0 then
        local vscroll = VScrollGroup:new{
            width  = inner_width,
            height = screen:scaleBySize(section.section_height),
            child  = row,
        }
        table.insert(refs.sliders, { slider = vscroll })
        content_widget = vscroll
    end
    table.insert(group, content_widget)

    return { widget = group , refs = refs }
end

-- ============================================================
-- Settings Menu Builder
-- ============================================================
function Info.getSettings(ctx, close, refresh, reload)
    -- ctx import
    local config  = ctx.config
    local section = Utils.getSection(config, Info.id)

    if not section then return {} end

    local menu_items = {
        {
            text = _("Enabled in reader"),
            checked_func = function() if reload then reload() end return section.enabled_r end,
            callback = function() section.enabled_r = not section.enabled_r; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Show title"),
            checked_func = function() if reload then reload() end return section.show_title end,
            callback = function() section.show_title = not section.show_title; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Show thumbnail"),
            checked_func = function() if reload then reload() end return section.show_thumbnail end,
            callback = function() section.show_thumbnail = not section.show_thumbnail; Config.saveAndRefresh(ctx) end
        },
        {
            text_func = function()
                if reload then reload() end
                if section.cover_side == "right" then return _("Cover position") .. " : " .. _("Right") end
                return _("Cover position") .. " : " .. _("Left")
            end,
            enabled_func = function() return section.show_thumbnail end,
            callback = function()
                section.cover_side = (section.cover_side == "right") and "left" or "right"
                Config.saveAndRefresh(ctx)
            end
        },
        {
            text_func = function()
                if reload then reload() end
                if section.thumbnail_mode == "preview" then return _("Thumbnail") .. " : " .. _("Page preview") end
                return _("Thumbnail") .. " : " .. _("Cover")
            end,
            enabled_func = function() return section.show_thumbnail end,
            callback = function()
                section.thumbnail_mode = (section.thumbnail_mode == "preview") and "cover" or "preview"
                Config.saveAndRefresh(ctx)
            end,
            separator = true
        },
        {
            text = _("Show title/author/chapter"),
            checked_func = function() if reload then reload() end return section.show_info_text end,
            callback = function() section.show_info_text = not section.show_info_text; Config.saveAndRefresh(ctx) end,
        },
        {
            text = _("Fonts (title/author/chapter)") .. "\xE2\x80\xA6",
            enabled_func = function() return section.show_info_text end,
            keep_menu_open = true,
            separator = true,
            callback = close(function()
                local function showSizeDialog(title, getValue, setValue, default_value)
                    local original = getValue()
                    local function rebuild() UIManager:setDirty("all", "ui") end
                    local dialog
                    local function nudge(delta)
                        setValue(math.max(0, math.min(60, getValue() + delta)))
                        dialog:reinit()
                        rebuild()
                    end
                    local function closeDialog() UIManager:close(dialog); refresh() end
                    local function revert() setValue(original); rebuild() end
                    dialog = ButtonDialog:new{
                        dismissable = false,
                        title = title,
                        buttons = {
                            {
                                { text = "-1", callback = function() nudge(-1) end },
                                { text_func = function()
                                    local v = getValue()
                                    return v == 0 and _("Auto") or tostring(v)
                                end, enabled = false },
                                { text = "+1", callback = function() nudge(1) end },
                            },
                            {
                                { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                                { text = _("Default"), callback = function() setValue(default_value); rebuild(); dialog:reinit() end },
                                { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                            },
                        },
                        tap_close_callback = revert
                    }
                    UIManager:show(dialog)
                end

                -- label: e.g. "Title" | font_key/size_key: e.g. "title_font"/"title_font_size"
                local function buildEntry(label, font_key, size_key)
                    return {
                        text = label,
                        sub_item_table_func = function()
                            local items = {
                                {
                                    text = _("Default (UI font)"),
                                    checked_func = function() return not section[font_key] end,
                                    radio = true,
                                    callback = function() section[font_key] = false; Config.saveAndRefresh(ctx) end,
                                },
                            }
                            FontList:getFontList()
                            for _, font_path in ipairs(FontList:getFontList()) do
                                local basename = fontBasename(font_path)
                                table.insert(items, {
                                    text = fontDisplayName(font_path),
                                    checked_func = function() return section[font_key] == basename end,
                                    radio = true,
                                    callback = function() section[font_key] = basename; Config.saveAndRefresh(ctx) end,
                                })
                            end
                            table.insert(items, {
                                text_func = function()
                                    local v = section[size_key]
                                    local lbl = (not v or v == 0) and _("Default") or tostring(v)
                                    return _("Font size") .. " (" .. lbl .. ")\xE2\x80\xA6"
                                end,
                                callback = function()
                                    showSizeDialog(
                                        label .. " - " .. _("Font size"),
                                        function() return section[size_key] or 0 end,
                                        function(v) section[size_key] = v; Config.saveAndRefresh(ctx) end,
                                        Config.DEFAULTS.sections.info[size_key]
                                    )
                                end,
                            })
                            return items
                        end,
                    }
                end

                local MenuHost = require("actionchooser/menu_host")
                MenuHost.show{
                    title = _("Fonts (title/author/chapter)"),
                    item_table = {
                        buildEntry(_("Title"), "title_font", "title_font_size"),
                        buildEntry(_("Author"), "author_font", "author_font_size"),
                        buildEntry(_("Chapter"), "chapter_font", "chapter_font_size"),
                    },
                }
            end),
        },
        {
            text = _("Show skim"),
            checked_func = function() if reload then reload() end return section.show_skim end,
            callback = function() section.show_skim = not section.show_skim; Config.saveAndRefresh(ctx) end,
        },
        {
            text = _("Skim: custom grid (like Actions)"),
            checked_func = function() if reload then reload() end return section.skim_grid_mode end,
            enabled_func = function() return section.show_skim end,
            callback = function() section.skim_grid_mode = not section.skim_grid_mode; Config.saveAndRefresh(ctx) end,
        },
        {
            text = _("Skim grid settings") .. "\xE2\x80\xA6",
            enabled_func = function() return section.show_skim and section.skim_grid_mode end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local Skim = require("sections/skim")
                Skim.showSettings(ctx)
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local a = section.page_tap_action
                local label = (a and a.label and a.label ~= "" and a.label) or _("Default (Go to page)")
                return _("Page number") .. " - " .. _("Tap") .. " : " .. label
            end,
            enabled_func = function() return section.show_skim end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                Info.showPageActionDialog(ctx, "page_tap_action", refresh)
            end)
        },
        {
            text_func = function()
                if reload then reload() end
                local a = section.page_hold_action
                local label = (a and a.label and a.label ~= "" and a.label) or _("Default (Back to previous page)")
                return _("Page number") .. " - " .. _("Hold") .. " : " .. label
            end,
            enabled_func = function() return section.show_skim end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                Info.showPageActionDialog(ctx, "page_hold_action", refresh)
            end),
            separator = true
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.slider_btn_width
                local label = (not v or v == 0) and _("Default") or tostring(v)
                return _("Page slider buttons width") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            enabled_func = function() return section.show_skim and not section.skim_grid_mode end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.slider_btn_width
                local function getValue() return section.slider_btn_width or 0 end
                local function setValue(v) section.slider_btn_width = math.max(0, math.min(200, v)); Config.saveAndRefresh(ctx, true) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Page slider buttons width") .. " (" .. _("0 = default") .. ")",
                    buttons = {
                        {
                            { text = "-10", callback = function() nudge(-10) end },
                            { text = "-1",  callback = function() nudge(-1)  end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("Default") or tostring(v)
                            end, enabled = false },
                            { text = "+1",  callback = function() nudge(1)   end },
                            { text = "+10", callback = function() nudge(10)  end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.info.slider_btn_width); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.slider_max_width
                local label = (not v or v == 0) and _("No limit") or tostring(v)
                return _("Page slider max width") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            enabled_func = function() return section.show_skim and not section.skim_grid_mode end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.slider_max_width
                local function getValue() return section.slider_max_width or 0 end
                local function setValue(v) section.slider_max_width = math.max(0, math.min(3000, v)); Config.saveAndRefresh(ctx, true) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Page slider max width") .. " (" .. _("0 = no limit") .. ")",
                    buttons = {
                        {
                            { text = "-50", callback = function() nudge(-50) end },
                            { text = "-10", callback = function() nudge(-10) end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("No limit") or tostring(v)
                            end, enabled = false },
                            { text = "+10", callback = function() nudge(10)  end },
                            { text = "+50", callback = function() nudge(50)  end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.info.slider_max_width); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text_func = function()
                if reload then reload() end
                local v = section.section_height
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Section height") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.section_height
                local function getValue() return section.section_height or 0 end
                local function setValue(v) section.section_height = math.max(0, math.min(3000, v)); Config.saveAndRefresh(ctx, true) end
                local function rebuild() UIManager:setDirty("all", "ui") end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function closeDialog() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Section height") .. " (" .. _("0 = auto, sin límite") .. ")",
                    buttons = {
                        {
                            { text = "-50", callback = function() nudge(-50) end },
                            { text = "-10", callback = function() nudge(-10) end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("Auto") or tostring(v)
                            end, enabled = false },
                            { text = "+10", callback = function() nudge(10)  end },
                            { text = "+50", callback = function() nudge(50)  end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); closeDialog() end },
                            { text = _("Default"), callback = function() setValue(Config.DEFAULTS.sections.info.section_height); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = closeDialog },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
        text = _("Reset section to defaults") .. "\xE2\x80\xA6",
        keep_menu_open = true,
        callback = close(function(touch_menu)
            if touch_menu then ctx.touch_menu = touch_menu end
            UIManager:show(ConfirmBox:new{
                text = _("Reset section to defaults") .. " ?",
                ok_text = _("Reset"),
                ok_callback = function()
                    local defaults = Config.DEFAULTS.sections[Info.id]
                    Utils.resetSectionToDefaults(section, defaults)
                    Config.saveAndRefresh(ctx)
                    if refresh then refresh() end
                end,
                cancel_callback = function()
                    if refresh then refresh() end
                end,
            })
        end)
        }
    }

    return menu_items
end

-- ============================================================
-- Page number tap/hold action picker
-- ============================================================
function Info.showPageActionDialog(ctx, key, refresh)
    local config  = ctx.config
    local section = Utils.getSection(config, Info.id)
    if not section then return end

    local dialog
    local no_close = function(fn) return fn end

    local function saveAction(fields)
        local action = {
            label       = fields.label,
            icon        = fields.icon,
            plugin      = fields.plugin,
            action      = fields.action,
            menu_path   = fields.menu_path,
            menu_toggle = fields.menu_toggle,
            menu_page   = fields.menu_page,
        }
        for k, v in pairs(action) do
            if (type(v) ~= "table" and (v == nil or v == "")) then
                action[k] = nil
            end
        end
        section[key] = action
        Config.saveAndRefresh(ctx)
    end

    local buttons = ActionChooser.actionRows(no_close, function(fields)
        UIManager:close(dialog)
        saveAction(fields)
        if refresh then refresh() end
    end)

    table.insert(buttons, {}) -- separator

    buttons[#buttons + 1] = {
        {
            text = _("Reset to default"),
            callback = function()
                UIManager:close(dialog)
                section[key] = {}
                Config.saveAndRefresh(ctx)
                if refresh then refresh() end
            end
        },
        {
            text = _("Exit"),
            callback = function()
                UIManager:close(dialog)
                if refresh then refresh() end
            end
        }
    }

    dialog = ButtonDialog:new{
        title = "\u{E8B6} " .. _("Choose action") .. " :",
        title_align  = "left",
        width_factor = 0.9,
        buttons = buttons,
        tap_close_callback = function()
            if refresh then refresh() end
        end,
    }
    UIManager:show(dialog)
end

function Info.showSettings(ctx)
    local dialog

    local function close(fn)
        return function()
            if dialog then UIManager:close(dialog) end
            if fn then fn() end
        end
    end

    local function refresh()
        Info.showSettings(ctx)
    end
    -- use to refresh under check btn when dialog is transparent
    -- cost perf so block at openig as dialog never open transparent
    -- only from the dialog from the touch_menu itself it crash koreader
    local reload, activateReload = Utils.debouncedReload(ctx)

    local buttons = Utils.wrap_items(Info.getSettings(ctx, close, refresh, reload))
    if not buttons or #buttons==0 then return end

    table.insert(buttons, {}) -- separator

    table.insert(buttons, {{
        text = _("Exit"),
        callback = close()
    }})

    dialog = ButtonDialog:new{
        -- dismissable = false,
        title = Info.icon .. " " .. Info.label .. " :",
        title_align  = "left",
        width_factor = 0.9,
        buttons = buttons,
    }
    UIManager:show(dialog)
    activateReload() -- allow reload after opening
end

return Info
