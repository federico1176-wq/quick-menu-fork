local Button          = require("ui/widget/button")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan  = require("ui/widget/verticalspan")

local Math            = require("optmath")
local Event           = require("ui/event")
local UIManager       = require("ui/uimanager")

local SliderSection   = require("sections/slidersection")
local SkimGrid        = require("sections/skimgrid")
local Utils           = require("common/utils")
local ActionExec      = require("action_exec")

local SkimSection = {}

function SkimSection.build(ctx)
    -- ctx import
    local config             = ctx.config
    local touch_menu         = ctx.touch_menu
    local reader             = ctx.reader
    local filemanager        = ctx.filemanager
    local device             = ctx.device
    local powerd             = ctx.powerd
    local screen             = ctx.screen
    local datetime           = ctx.datetime
    local stat               = ctx.stat
    local panel_width        = ctx.panel_width
    local inner_width        = ctx.inner_width
    local h_gap              = screen:scaleBySize(config.style.h_gap or 4)
    local v_gap              = screen:scaleBySize(config.style.v_gap or 4)
    local btn_width          = screen:scaleBySize(config.style.btn_width or 50)
    local btn_radius         = screen:scaleBySize(config.style.btn_radius or 7)
    local btn_bordersize     = screen:scaleBySize(config.style.btn_bordersize or 1.5)
    local btn_font_size      = config.style.btn_font_size or 16
    local slider_ticks_width = screen:scaleBySize(config.style.slider_ticks_width or 1)


    local refs = { buttons = {}, sliders = {}, widgets = {} }
    local group = VerticalGroup:new{ align = "center" }

    -- Utilitaires de gestion du menu
    local function closeMenu()
        if touch_menu and touch_menu.closeMenu then
            touch_menu:closeMenu()
        end
    end

    local function refreshMenu()
        if touch_menu and touch_menu.updateItems then
            touch_menu:updateItems(1)
        end
    end

    local skim = {
        curr_page  = touch_menu.qs_preview_page or reader:getCurrentPage(),
        page_count = reader.document:getPageCount()
    }
    touch_menu.qs_preview_page = skim.curr_page

    -- Configurable page-number tap/hold action (falls back to default behaviour
    -- when unset, i.e. empty table)
    local info_section = Utils.getSection(config, "info")

    local function hasCustomAction(a)
        return a ~= nil and (a.plugin ~= nil or a.action ~= nil or a.menu_path ~= nil)
    end

    local function runCustomAction(a)
        closeMenu()
        UIManager:nextTick(function() ActionExec.dispatch(a) end)
    end

    -- Logique de Navigation
    local function addOrigin()
        if not touch_menu.skim_orig_page then
            reader.link:addCurrentLocationToStack()
            touch_menu.skim_orig_page = reader:getCurrentPage()
        end
    end

    -- Chapter chevrons and the slider only move the PREVIEW target; they never
    -- touch the real reading position (like the page browser). Use the preview
    -- thumbnail (when enabled) or the page-number tap action to actually jump.
    local function goToPage(page)
        local new_page = math.max(1, math.min(skim.page_count, page))
        if skim.curr_page == new_page then return end
        skim.curr_page = new_page
        touch_menu.qs_preview_page = new_page
    end

    -- Commits the current preview page as the real reading position.
    local function commitPreview()
        if skim.curr_page == reader:getCurrentPage() then return end
        addOrigin()
        reader:handleEvent(Event:new("GotoPage", skim.curr_page))
    end

    -- Discards the preview and snaps it back to the real current page.
    local function resetPreview()
        skim.curr_page = reader:getCurrentPage()
        touch_menu.qs_preview_page = nil
    end

    local function goToOrig()
        if touch_menu.skim_orig_page then
            reader.link:onGoBackLink()
            touch_menu.skim_orig_page = nil
            refreshMenu()
        end
    end

    local function goEvent(name)
        addOrigin()
        reader:handleEvent(Event:new(name, false))
    end

    -- ============================================================
    -- Skim-only action API, used by sections/skim_action_defs.lua's
    -- callbacks when the skim area renders as a grid (info.skim_grid_mode).
    -- ============================================================
    ctx.skim = {
        prevChapter = function()
            local p = reader.toc:getPreviousChapter(skim.curr_page)
            if p then goToPage(p) end
            refreshMenu()
        end,
        nextChapter = function()
            local p = reader.toc:getNextChapter(skim.curr_page)
            if p then goToPage(p) end
            refreshMenu()
        end,
        firstPage = function() goToPage(1); refreshMenu() end,
        lastPage  = function() goToPage(skim.page_count); refreshMenu() end,
        showToc     = function() closeMenu(); goEvent("ShowToc") end,
        showBookMap = function() closeMenu(); goEvent("ShowBookMap") end,
        getCurrPage = function() return skim.curr_page end,
        pageTap = function()
            local a = info_section and info_section.page_tap_action
            if hasCustomAction(a) then runCustomAction(a)
            else closeMenu(); goEvent("ShowGotoDialog") end
        end,
        pageHold = function()
            local a = info_section and info_section.page_hold_action
            if hasCustomAction(a) then runCustomAction(a)
            else goToOrig() end
        end,
        prevBookmark = function() goEvent("GotoPreviousBookmarkFromPage"); refreshMenu() end,
        nextBookmark = function() goEvent("GotoNextBookmarkFromPage"); refreshMenu() end,
        isBookmarked = function() return reader.view.dogear_visible end,
        toggleBookmark = function() goEvent("ToggleBookmark"); refreshMenu() end,
        showBookmark = function() closeMenu(); goEvent("ShowBookmark") end,
    }

    -- ============================================================
    -- Grid mode (opt-in): the whole area (bar + navigation) renders as a
    -- single configurable grid, exactly like the Actions section.
    -- ============================================================
    if info_section and info_section.skim_grid_mode then
        local grid = SkimGrid.build(ctx, { skim = skim, goToPage = goToPage, info_section = info_section })
        if grid then
            for _, sr in ipairs(grid.refs.sliders) do
                table.insert(refs.sliders, sr)
            end
            return {
                widget = grid.widget,
                refs = refs,
                getPreviewPage = function() return skim.curr_page end,
                commitPreview = commitPreview,
                resetPreview = resetPreview,
            }
        end
        -- falls through to the default layout below if the grid has no items
    end

    -- ============================================================
    -- Default layout: progress bar (row 1) + fixed navigation row (row 2)
    -- ============================================================
    local skim_slider_btn_width = (info_section and info_section.slider_btn_width and info_section.slider_btn_width > 0)
        and screen:scaleBySize(info_section.slider_btn_width) or btn_width
    local skim_slider_max_width = (info_section and info_section.slider_max_width and info_section.slider_max_width > 0)
        and screen:scaleBySize(info_section.slider_max_width) or nil

    local row1 = SliderSection.build{
        touch_menu         = touch_menu,
        inner_width        = inner_width,
        screen             = screen,

        btn_width          = skim_slider_btn_width,
        max_width          = skim_slider_max_width,
        btn_radius         = btn_radius,
        btn_bordersize     = btn_bordersize,
        btn_font_size      = btn_font_size,
        slider_ticks_width = slider_ticks_width,
        h_gap              = h_gap,

        min                = 1,
        max                = skim.page_count,
        get                = function() return skim.curr_page end,
        set                = goToPage,
        text_minus         = "\u{F056}",
        text_plus          = "\u{F055}",
        initial_pos_marker = true,
    }

    local progress = row1.refs.sliders[1].widget
    progress.ticks              = reader.toc:getTocTicksFlattened()
    progress.tick_width         = slider_ticks_width
    progress.alt                = reader.document.flows
    progress.initial_percentage = (touch_menu.skim_orig_page or skim.curr_page) / skim.page_count

    -- Row 2: Navigation
    local function createBtn(props)
        props.width = props.width or btn_width
        props.radius = btn_radius
        props.bordersize = btn_bordersize
        props.text_font_size = btn_font_size
        props.show_parent = touch_menu.show_parent
        return Button:new(props)
    end

    local h_gap2 = Math.round((inner_width - 7 * btn_width - 4 * h_gap) / 2)
    local row2 = HorizontalGroup:new{ align = "center" }

    table.insert(row2, createBtn{ text = "\u{25C0}", callback = ctx.skim.prevChapter, hold_callback = ctx.skim.firstPage })
    table.insert(row2, HorizontalSpan:new{ width = h_gap })
    table.insert(row2, createBtn{ text = "\u{F0C9}", callback = ctx.skim.showToc, hold_callback = ctx.skim.showBookMap })
    table.insert(row2, HorizontalSpan:new{ width = h_gap })
    table.insert(row2, createBtn{ text = "\u{25B6}", callback = ctx.skim.nextChapter, hold_callback = ctx.skim.lastPage })

    table.insert(row2, HorizontalSpan:new{ width = h_gap2 })
    table.insert(row2, createBtn{
        text_func = function() return tostring(skim.curr_page) end,
        callback = ctx.skim.pageTap,
        hold_callback = ctx.skim.pageHold,
    })
    table.insert(row2, HorizontalSpan:new{ width = h_gap2 })

    table.insert(row2, createBtn{ text = "\u{25C0}", callback = ctx.skim.prevBookmark })
    table.insert(row2, HorizontalSpan:new{ width = h_gap })
    table.insert(row2, createBtn{ text_func = function() return ctx.skim.isBookmarked() and "\u{F02E}" or "\u{F097}" end, callback = ctx.skim.toggleBookmark, hold_callback = ctx.skim.showBookmark })
    table.insert(row2, HorizontalSpan:new{ width = h_gap })
    table.insert(row2, createBtn{ text = "\u{25B6}", callback = ctx.skim.nextBookmark })

    table.insert(group, row1.widget)
    table.insert(group, VerticalSpan:new{ width = v_gap })
    table.insert(group, row2)

    table.insert(refs.sliders, row1.refs.sliders[1])

    return {
        widget = group,
        refs = refs,
        getPreviewPage = function() return skim.curr_page end,
        commitPreview = commitPreview,
        resetPreview = resetPreview,
    }
end

return SkimSection
