local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local VerticalGroup   = require("ui/widget/verticalgroup")
local TextWidget      = require("ui/widget/textwidget")
local Font            = require("ui/font")

local UIManager       = require("ui/uimanager")

local ActionDefs      = require("action_defs")
local ActionExec      = require("action_exec")
local ActionButton    = require("widgets/actionbutton")
local Utils           = require("common/utils")

local FrontlightToggle = {}

-- ids of the actions exposed as quick toggle buttons beside the brightness bar
FrontlightToggle.ids = { "night", "light" }

-- Same glyphs used by the brightness slider's minus/plus buttons, so the
-- light toggle button visually matches the bar it mirrors.
local ICON_LIGHT_ON  = "\u{EA2B}" -- led-on
local ICON_LIGHT_OFF = "\u{EA2D}" -- led-off

-- Formats the value shown inside the light toggle button: the "light on"
-- icon next to the current brightness number, or just the "light off" icon
-- alone when brightness is 0.
function FrontlightToggle.formatLightValue(v)
    v = tonumber(v) or 0
    if v <= 0 then
        return ICON_LIGHT_OFF
    end
    return ICON_LIGHT_ON .. " " .. tostring(v)
end

-- Builds the light/night toggle buttons using the exact same action
-- definitions (icon, label, active state, tap/hold behavior) and the same
-- circular button size/style as the Actions section, with the label shown
-- below each button.
-- Returns the HorizontalGroup widget, or nil if no action is available.
function FrontlightToggle.build(ctx)
    local config     = ctx.config
    local touch_menu = ctx.touch_menu
    local powerd     = ctx.powerd
    local screen     = ctx.screen

    local h_gap           = screen:scaleBySize(config.style.h_gap or 4)
    local btn_bordersize  = screen:scaleBySize(config.style.btn_bordersize or 1.5)

    -- size stays fully independent (own setting)
    local raw_size   = config.style.toggle_action_size or config.style.action_size or 64
    local action_size = screen:scaleBySize(raw_size)

    -- shape: independent from Actions, own setting; 0 = square, size/2 = circle
    local raw_radius = config.style.toggle_action_radius
    if raw_radius == nil then raw_radius = raw_size / 2 end
    raw_radius = math.max(0, math.min(raw_radius, raw_size / 2))
    local action_radius = math.floor(screen:scaleBySize(raw_radius))

    local ratio            = screen:scaleBySize(100) / 100
    local action_icon_size  = math.floor((action_size * 0.4) / ratio + 0.5)
    local action_label_size = math.floor((action_size * 0.18) / ratio + 0.5)
    -- brightness value inside the light button is often 2-3 digits, so it
    -- gets a slightly smaller font than a single glyph icon to keep it
    -- comfortably inside the box
    local light_value_size  = math.max(1, math.floor(action_icon_size * 0.85))

    local action_defs = ActionDefs.getMerged(config.custom_actions)

    local fl_section = Utils.getSection(config, "frontlight")
    local show_labels = not fl_section or fl_section.show_toggle_labels ~= false

    -- kept so callers (frontlight.lua / intensityzenui.lua) can push live
    -- brightness updates into the button without rebuilding the whole panel
    local light_btn_ref = nil

    local function exec_action(action_data)
        if type(action_data) == "function" then -- native
            action_data(ctx)
        elseif type(action_data) == "table" then -- custom
            touch_menu:closeMenu()
            UIManager:nextTick(function() ActionExec.dispatch(action_data) end)
        end
    end

    local function create_btn(id)
        local def = action_defs[id]
        if not def then return nil end

        local is_light = (id == "light")

        -- for the light button, the icon glyph is replaced by the current
        -- brightness value (always numeric, even when the light is off)
        local icon_val = def.icon_func and def.icon_func(ctx) or (def.icon or "")
        local icon_size = action_icon_size
        if is_light then
            icon_val = powerd and FrontlightToggle.formatLightValue(powerd:frontlightIntensity()) or ICON_LIGHT_OFF
            icon_size = light_value_size
        end

        local btn = ActionButton:new{
            icon          = icon_val,
            size          = action_size,
            radius        = action_radius,
            icon_size     = icon_size,
            bordersize    = btn_bordersize,
            is_active     = def.active_func and def.active_func(ctx) or false,
            no_active_bg  = true, -- frontlight toggle buttons: keep background fixed, only the inner icon changes
            callback      = def.callback and function() exec_action(def.callback) end or nil,
            hold_callback = def.hold_callback and function() exec_action(def.hold_callback) end or nil,
        }

        if is_light then light_btn_ref = btn end

        if not show_labels then
            return btn
        end

        -- caption below: since the value now lives inside the button, the
        -- light caption falls back to the static label ("Light") instead of
        -- repeating the number; night keeps its dynamic Day/Night caption
        local caption_text = is_light
            and (def.label or "")
            or (def.label_func and def.label_func(ctx) or (def.label or ""))

        return VerticalGroup:new{
            align = "center",
            btn,
            TextWidget:new{
                text = caption_text,
                face = Font:getFace("cfont", action_label_size),
                max_width = action_size,
            }
        }
    end

    local group = HorizontalGroup:new{ align = "center" }
    local first = true
    for _, id in ipairs(FrontlightToggle.ids) do
        local btn = create_btn(id)
        if btn then
            if not first then
                table.insert(group, HorizontalSpan:new{ width = h_gap })
            end
            table.insert(group, btn)
            first = false
        end
    end

    if #group == 0 then return nil end
    return { widget = group, refs = { light_button = light_btn_ref } }
end

return FrontlightToggle
