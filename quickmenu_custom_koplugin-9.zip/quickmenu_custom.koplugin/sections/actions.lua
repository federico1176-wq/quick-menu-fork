local Button          = require("ui/widget/button")
local ButtonDialog    = require("ui/widget/buttondialog")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local TextWidget      = require("ui/widget/textwidget")
local ConfirmBox      = require("ui/widget/confirmbox")

local Font            = require("ui/font")

local Math            = require("optmath")
local UIManager       = require("ui/uimanager")

local ActionExec      = require("action_exec")
local ActionDefs      = require("action_defs")
local ActionManage    = require("action_manage")
local Config          = require("config")
local ActionButton    = require("widgets/actionbutton")
local Utils           = require("common/utils")
local ShadowDeco      = require("widgets/shadow_deco")
local Blitbuffer      = require("ffi/blitbuffer")
local _               = require("common/i18n").gettext

local Actions = {
    id = "actions",
    label = _("Actions"),
    icon  = "\u{E767}" --auto fix
}

-- ============================================================
-- Actions Builder
-- ============================================================
function Actions.build(ctx)
    -- ctx import
    local config             = ctx.config
    local touch_menu         = ctx.touch_menu
    local reader             = ctx.reader
    local filemanager        = ctx.filemanager
    local device             = ctx.device
    local powerd             = ctx.powerd
    local screen             = ctx.screen
    local datetime           = ctx.datetime
    local stat               = ctx.stat
    local panel_width        = ctx.panel_width
    local inner_width        = ctx.inner_width
    local h_gap              = screen:scaleBySize(config.style.h_gap or 4)
    local v_gap              = screen:scaleBySize(config.style.v_gap or 4)
    local action_size        = screen:scaleBySize(config.style.action_size or 64)
    local action_radius      = screen:scaleBySize(config.style.action_radius or 32)
    local btn_width          = screen:scaleBySize(config.style.btn_width or 50)
    local btn_radius         = screen:scaleBySize(config.style.btn_radius or 7)
    local btn_bordersize     = screen:scaleBySize(config.style.btn_bordersize or 1.5)
    local btn_font_size      = config.style.btn_font_size or 16
    local slider_ticks_width = screen:scaleBySize(config.style.slider_ticks_width or 1)
    local rect_btn_bordersize = screen:scaleBySize(config.style.rect_button_bordersize or 1.5)
    local rect_btn_bordercolor = Blitbuffer.gray(config.style.rect_button_border_intensity or 0)

    local section = Utils.getSection(config, Actions.id)
    local row_gap = (section and section.row_gap and section.row_gap > 0) and screen:scaleBySize(section.row_gap) or v_gap

    if not section then return nil end

    if filemanager and not section.enabled_f then return nil end

    if reader and not section.enabled_r then return nil end

    section.items = section.items or {}

    -- actions system and custom
    local action_defs = ActionDefs.getMerged(config.custom_actions)

    local visible_actions = {}
    for i, id in ipairs(section.items) do
        local def = action_defs[id]
        if def and (not def.visible_func or def.visible_func(ctx)) then
            table.insert(visible_actions, { id = id, def = def })
        end
    end

    local num_actions = #visible_actions
    if num_actions == 0 then return nil end

    local group = VerticalGroup:new{ align = "center" }

    -- title
    if section.show_title then
        -- collapse
        local collapse_btn = Button:new{
            text           = section.collapse and "▶" or "▼",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                section.collapse = not section.collapse
                Config.saveAndRefresh(ctx, true) -- no flush
            end,
            --hold_callback = function() end,
        }
        -- add icon near section name when collapse
        local label_icon = ""
        if section.collapse then
            for _, entry in ipairs(visible_actions) do
                local def = entry.def
                local icon = def.icon_func and def.icon_func(ctx) or (def.icon or "")
                label_icon = label_icon .. " " .. Utils.get_safe_icon(icon)
            end
        end
        -- section name
        local label_title = TextWidget:new{
            text = Actions.label .. " : " .. label_icon,
            face =  Font:getFace("cfont", btn_font_size), bold = true,
            max_width = inner_width - btn_width*2,
        }
        local settings_btn = Button:new{
            text           = "\u{EB92}",
            width          = btn_width,
            radius         = btn_radius,
            bordersize     = 0,
            text_font_size = btn_font_size,
            show_parent    = touch_menu.show_parent,
            callback       = function()
                Actions.showSettings(ctx)
            end,
            --hold_callback = function() end,
        }
        --
        local row_title = HorizontalGroup:new{
            collapse_btn,
            align = "center",
            label_title,
            HorizontalSpan:new{ width = inner_width - label_title:getSize().w - btn_width*2 },
            settings_btn,
        }
        --
        table.insert(group, row_title)
        -- stop render if section is collapse
        if section.collapse then  return { widget = group } end
    else
        table.insert(group, VerticalSpan:new{ width = screen:scaleBySize( 10 ) }) -- better for visual
    end

    -- utils to exec actions
    local function exec_action(ctx, action_data)
        if type(action_data) == "function" then -- native
            action_data(ctx)
        elseif type(action_data) == "table" then -- custom
            ctx.touch_menu:closeMenu()
            UIManager:nextTick(function() ActionExec.dispatch(action_data) end)
        end
    end

    -- ============================================================
    -- Rectangular mode (buttons like Shortcuts: fixed columns, icon + label inline)
    -- ============================================================
    if section.rect_ctrl then
        local rect_height = (section.rect_height and section.rect_height > 0) and screen:scaleBySize(section.rect_height) or nil

        local rows = Utils.buildRows(
            num_actions,
            section.custom_rows and section.row_pattern or nil,
            (section.max_cols and section.max_cols > 0) and section.max_cols or nil
        )

        local function create_rect_btn(entry, row_width)
            local def = entry.def
            local icon = def.icon_func and def.icon_func(ctx) or (def.icon or "")
            local label = def.label_func and def.label_func(ctx) or (def.label or "")
            local btn_text = section.show_label and (Utils.get_safe_icon(icon) .. " " .. _(label)) or Utils.get_safe_icon(icon)
            local btn = Button:new{
                text           = btn_text,
                width          = row_width,
                height         = rect_height,
                radius         = btn_radius,
                bordersize     = rect_btn_bordersize,
                background     = Blitbuffer.COLOR_WHITE,
                text_font_size = btn_font_size,
                show_parent    = touch_menu.show_parent,
                callback       = def.callback and function() exec_action(ctx, def.callback) end or nil,
                hold_callback  = def.hold_callback and function() exec_action(ctx, def.hold_callback) end or nil,
            }
            btn.frame.color = rect_btn_bordercolor
            ShadowDeco.attach(btn)
            return btn
        end

        local idx = 1
        for _, count in ipairs(rows) do
            local row_end = math.min(idx + count - 1, num_actions)
            local n = row_end - idx + 1
            if n > 0 then
                -- always sized off this row's own item count, so a row with
                -- free space (fewer items) still fills the full width
                local row_width = Math.round((inner_width - h_gap * (n - 1)) / n)
                local row = HorizontalGroup:new{ align = "center" }
                for j = idx, row_end do
                    table.insert(row, create_rect_btn(visible_actions[j], row_width))
                    if j < row_end then
                        table.insert(row, HorizontalSpan:new{ width = h_gap })
                    end
                end
                table.insert(group, row)
                if row_end < num_actions then
                    table.insert(group, VerticalSpan:new{ width = row_gap })
                end
                idx = row_end + 1
            end
        end

        return { widget = group }
    end

    -- Logique de calcul selon le mode
    local action_radius_ratio = action_radius / action_size -- 0 square 0.5 circle
    local action_btn_size = action_size -- height (and icon/label scale) stay fixed
    local ratio = screen:scaleBySize(100) / 100

    -- when a fixed column count is set, size buttons based on columns per row
    -- instead of the total action count
    local has_max_cols = section.max_cols and section.max_cols > 0
    local cols_for_fit = has_max_cols and math.min(section.max_cols, num_actions) or num_actions
    local computed_fit = math.floor( (inner_width - (cols_for_fit - 1) * h_gap ) / math.max(1, cols_for_fit))

    if section.fit_ctrl then
        action_btn_size = math.min(computed_fit, action_btn_size)
    end

    -- stretch only widens the button (pill shape); height/icon/label keep their size
    local action_btn_width = action_btn_size
    if section.stretch_ctrl then
        action_btn_width = math.max(1, computed_fit)
    end

    local action_btn_radius = math.floor(action_btn_size * action_radius_ratio)
    local action_icon_size = math.floor((action_btn_size * 0.4) / ratio + 0.5)
    local action_label_size = (section.label_size and section.label_size > 0)
        and section.label_size
        or math.floor((action_btn_size * 0.18) / ratio + 0.5)

    -- Construction des boutons
    local function create_btn(entry, btn_width)
        local def = entry.def
        local label_text = section.show_label and (def.label_func and def.label_func(ctx) or def.label) or nil
        local label_inside = section.label_inside and label_text

        local btn = ActionButton:new{
            icon          = def.icon_func and def.icon_func(ctx) or (def.icon or ""),
            width         = btn_width or action_btn_width,
            height        = action_btn_size,
            radius        = action_btn_radius,
            icon_size     = action_icon_size,
            bordersize    = btn_bordersize,
            is_active     = def.active_func and def.active_func(ctx) or false,
            callback      = def.callback and function() exec_action(ctx, def.callback) end or nil,
            hold_callback = def.hold_callback and function() exec_action(ctx, def.hold_callback) end or nil,
            label         = label_inside and label_text or nil,
            label_face    = label_inside and Font:getFace("cfont", action_label_size) or nil,
        }
        if label_text and not label_inside then
            return VerticalGroup:new{
                align = "center",
                btn,
                TextWidget:new{
                    text = label_text,
                    face = Font:getFace("cfont", action_label_size),
                    max_width = btn_width or action_btn_width,
                }
            }
        end
        return btn
    end

    -- custom per-row pattern (2 on row 1, 3 on row 2, etc.), if enabled
    local custom_rows = (section.custom_rows and section.row_pattern and #section.row_pattern > 0)
        and Utils.buildRows(num_actions, section.row_pattern, has_max_cols and section.max_cols or nil)
        or nil

    -- action btn placement
    local i = 1
    local row_i = 1
    while i <= num_actions do
        local row_actions = {}
        local current_row_w = 0
        local start_i = i

        if custom_rows then
            local count = custom_rows[row_i] or 1
            local row_end = math.min(i + count - 1, num_actions)
            for j = i, row_end do table.insert(row_actions, visible_actions[j]) end
            i = row_end + 1
            row_i = row_i + 1
        else
            -- fill the line till the line is full
            while i <= num_actions do
                local col_index = i - start_i
                local reached_max_cols = has_max_cols and col_index >= section.max_cols
                local next_w = current_row_w + (col_index > 0 and h_gap or 0) + action_btn_width
                local width_overflow = not has_max_cols and not section.fit_ctrl and not section.stretch_ctrl and col_index > 0 and next_w > inner_width

                if reached_max_cols or width_overflow then break end

                table.insert(row_actions, visible_actions[i])
                current_row_w = next_w
                i = i + 1
            end
        end

        local n = #row_actions

        -- when stretching (or a custom row pattern is active), each row
        -- fills the full available width based on its own item count, so a
        -- shorter row doesn't leave dead space
        local row_btn_width = action_btn_width
        if n > 0 and (section.stretch_ctrl or custom_rows) then
            row_btn_width = math.max(1, math.floor((inner_width - (n - 1) * h_gap) / n))
        end

        -- gap
        local gap = h_gap
        if section.justified_ctrl and not (section.stretch_ctrl or custom_rows) and n > 1 then
            gap = math.floor((inner_width - (n * action_btn_width)) / (n - 1))
        end

        -- store the line
        local row = HorizontalGroup:new{ align = "center" }
        for j, entry in ipairs(row_actions) do
            if j > 1 then
                table.insert(row, HorizontalSpan:new{ width = gap })
            end
            table.insert(row, create_btn(entry, row_btn_width))
        end
        table.insert(group, row)
        if i <= num_actions then
            table.insert(group, VerticalSpan:new{ width = row_gap })
        end
    end

    return { widget = group }
end

-- ============================================================
-- Settings Menu Builder
-- ============================================================
function Actions.getSettings(ctx, close, refresh, reload)
    local config = ctx.config
    local section = Utils.getSection(config, Actions.id)
    if not section then return {} end

    -- global
    local menu_items = {
        {
            text = _("Enabled in filemanager"),
            checked_func = function() if reload then reload() end return section.enabled_f end,
            callback = function() section.enabled_f = not section.enabled_f; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Enabled in reader"),
            checked_func = function() if reload then reload() end return section.enabled_r end,
            callback = function() section.enabled_r = not section.enabled_r; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Show title"),
            checked_func = function() if reload then reload() end  return section.show_title end,
            callback = function() section.show_title = not section.show_title; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Show labels"),
            checked_func = function() if reload then reload() end return section.show_label end,
            callback = function() section.show_label = not section.show_label; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Label inside icon box"),
            checked_func = function() if reload then reload() end return section.label_inside end,
            callback = function() section.label_inside = not section.label_inside; Config.saveAndRefresh(ctx) end
        },
        {
            text_func = function()
                local v = section.label_size
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Label size (icon mode)") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.label_size
                local function getValue() return section.label_size or 0 end
                local function setValue(v) section.label_size = math.max(0, math.min(40, v)); Config.saveAndRefresh(ctx) end
                local function rebuild()
                    UIManager:setDirty("all", "ui")
                end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function close() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Label size (icon mode)"),
                    buttons = {
                        {
                            { text = "-1",   callback = function() nudge(-1)  end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("Auto") or tostring(v)
                            end, enabled = false },
                            { text = "+1",   callback = function() nudge(1)   end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); close() end },
                            { text = _("Default"),callback = function() setValue(Config.DEFAULTS.sections.actions.label_size); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = close },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text = _("Fit controls"),
            checked_func = function() if reload then reload() end  return section.fit_ctrl end,
            callback = function() section.fit_ctrl = not section.fit_ctrl; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Stretch controls"),
            checked_func = function() if reload then reload() end  return section.stretch_ctrl end,
            callback = function() section.stretch_ctrl = not section.stretch_ctrl; Config.saveAndRefresh(ctx) end
        },
        {
            text = _("Justify controls"),
            checked_func = function() if reload then reload() end  return section.justified_ctrl end,
            callback = function() section.justified_ctrl = not section.justified_ctrl; Config.saveAndRefresh(ctx) end,
        },
        {
            text = _("Rectangular buttons"),
            checked_func = function() if reload then reload() end  return section.rect_ctrl end,
            callback = function() section.rect_ctrl = not section.rect_ctrl; Config.saveAndRefresh(ctx) end,
        },
        {
            text_func = function()
                local v = section.rect_height
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Row height (rect.)") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.rect_height
                local function getValue() return section.rect_height or 0 end
                local function setValue(v) section.rect_height = math.max(0, math.min(200, v)); Config.saveAndRefresh(ctx) end
                local function rebuild()
                    UIManager:setDirty("all", "ui")
                end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function close() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Row height (rect.)"),
                    buttons = {
                        {
                            { text = "-4",   callback = function() nudge(-4)  end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("Auto") or tostring(v)
                            end, enabled = false },
                            { text = "+4",   callback = function() nudge(4)   end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); close() end },
                            { text = _("Default"),callback = function() setValue(Config.DEFAULTS.sections.actions.rect_height); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = close },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text_func = function()
                local v = section.row_gap
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Row spacing") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.row_gap
                local function getValue() return section.row_gap or 0 end
                local function setValue(v) section.row_gap = math.max(0, math.min(100, v)); Config.saveAndRefresh(ctx) end
                local function rebuild()
                    UIManager:setDirty("all", "ui")
                end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function close() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Row spacing"),
                    buttons = {
                        {
                            { text = "-2",   callback = function() nudge(-2)  end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("Auto") or tostring(v)
                            end, enabled = false },
                            { text = "+2",   callback = function() nudge(2)   end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); close() end },
                            { text = _("Default"),callback = function() setValue(Config.DEFAULTS.sections.actions.row_gap); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = close },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
        {
            text = _("Custom row pattern"),
            checked_func = function() if reload then reload() end return section.custom_rows end,
            callback = function() section.custom_rows = not section.custom_rows; Config.saveAndRefresh(ctx) end,
        },
        {
            text_func = function()
                local n = section.row_pattern and #section.row_pattern or 0
                return _("Icons per row") .. " (" .. n .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                Utils.showRowPatternEditor(ctx, Actions.id, refresh)
            end),
        },
        {
            text_func = function()
                local v = section.max_cols
                local label = (not v or v == 0) and _("Auto") or tostring(v)
                return _("Columns") .. " (" .. label .. ")\xE2\x80\xA6"
            end,
            keep_menu_open = true,
            separator = true,
            callback = close(function(touch_menu)
                if touch_menu then ctx.touch_menu = touch_menu end
                local original = section.max_cols
                local function getValue() return section.max_cols or 0 end
                local function setValue(v) section.max_cols = math.max(0, math.min(15, v)); Config.saveAndRefresh(ctx) end
                local function rebuild()
                    UIManager:setDirty("all", "ui") -- HACK touch_menu only repaint touch_menu... dialog outside touch_menu need repaint
                end

                local dialog
                local function nudge(delta)
                    setValue(getValue() + delta)
                    dialog:reinit()
                    rebuild()
                end

                local function close() UIManager:close(dialog); refresh() end
                local function revert() setValue(original); rebuild() end

                dialog = ButtonDialog:new{
                    dismissable = false,
                    title = _("Columns"),
                    buttons = {
                        {
                            { text = "-1",   callback = function() nudge(-1)  end },
                            { text_func = function()
                                local v = getValue()
                                return v == 0 and _("Auto") or tostring(v)
                            end, enabled = false },
                            { text = "+1",   callback = function() nudge(1)   end },
                        },
                        {
                            { text = _("Cancel"), callback = function() revert(); close() end },
                            { text = _("Default"),callback = function() setValue(Config.DEFAULTS.sections.actions.max_cols); rebuild(); dialog:reinit() end },
                            { text = _("Apply"), is_enter_default = true, callback = close },
                        },
                    },
                    tap_close_callback = revert
                }
                UIManager:show(dialog)
            end),
        },
    }

    local action_buttons = ActionManage:btnActionManageMenu(ctx, Actions.id, close, refresh)
    -- convert {{...}} in {}
    local flat_buttons = Utils.unwrap_items(action_buttons)
    for i, btn in ipairs(flat_buttons) do
        -- keep_menu_open
        btn.keep_menu_open = true
        -- add touch_menu to ctx
        local original_callback = btn.callback
        btn.callback = function(touch_menu)
            if touch_menu then ctx.touch_menu = touch_menu end
            if original_callback then return original_callback() end
        end
        -- add separator for last item
        btn.separator = (i == #flat_buttons)
        table.insert(menu_items, btn)
    end

    -- reset
    table.insert(menu_items, {
        text = _("Reset section to defaults") .. "\xE2\x80\xA6",
        keep_menu_open = true,
        callback = close(function(touch_menu)
            if touch_menu then ctx.touch_menu = touch_menu end
            UIManager:show(ConfirmBox:new{
                text = _("Reset section to defaults") .. " ?",
                ok_text = _("Reset"),
                ok_callback = function()
                    local defaults = Config.DEFAULTS.sections[Actions.id]
                    Utils.resetSectionToDefaults(section, defaults)
                    Config.saveAndRefresh(ctx)
                    if refresh then refresh() end
                end,
                cancel_callback = function()
                    if refresh then refresh() end
                end,
            })
        end)
    })

    return menu_items
end

function Actions.showSettings(ctx)
    local dialog

    local function close(fn)
        return function()
            if dialog then UIManager:close(dialog) end
            if fn then fn() end
        end
    end

    local function refresh()
        Actions.showSettings(ctx)
    end
    -- use to refresh under check btn when dialog is transparent
    -- cost perf so block at openig as dialog never open transparent
    -- only from the dialog from the touch_menu itself it crash koreader
    local reload, activateReload = Utils.debouncedReload(ctx)

    local buttons = Utils.wrap_items(Actions.getSettings(ctx, close, refresh, reload))
    if not buttons or #buttons==0 then return end

    table.insert(buttons, {}) -- separator

    table.insert(buttons, {{
        text = _("Exit"),
        callback = close()
    }})

    dialog = ButtonDialog:new{
        -- dismissable = false,
        title = Actions.icon .. " " .. Actions.label .. " :",
        title_align  = "left",
        width_factor = 0.9,
        buttons = buttons,
        tap_close_callback = close()
    }
    UIManager:show(dialog)
    activateReload() -- allow reload after opening
end

return Actions
