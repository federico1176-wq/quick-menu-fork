-- Skim-only action definitions.
--
-- These follow the same shape as entries in action_defs.lua (icon/icon_func,
-- label/label_func, category, callback, hold_callback, visible_func) so they
-- can be selected, sorted, and rendered through the exact same machinery
-- (ActionManage picker/sorter, Actions-style grid renderer).
--
-- They are kept OUT of the shared action_defs.lua on purpose: they only make
-- sense inside the skim area (they operate on the skim preview page, not the
-- real reading position), so they're merged in only when building/picking
-- for the "skim" section (see action_manage.lua and sections/skimgrid.lua).
--
-- Callbacks receive `ctx` like any other action def, but expect ctx.skim to
-- be present (injected by sections/skimsection.lua before dispatch) exposing
-- the skim-specific API: prevChapter/nextChapter/firstPage/lastPage/showToc/
-- showBookMap/getCurrPage/pageTap/pageHold/prevBookmark/nextBookmark/
-- toggleBookmark/isBookmarked/showBookmark.

local _ = require("common/i18n").gettext

local M = {}

M["skim_prev_chapter"] = {
    label    = _("Previous chapter"),
    icon     = "\u{25C0}",
    category = "skim",
    callback      = function(ctx) ctx.skim.prevChapter() end,
    hold_callback = function(ctx) ctx.skim.firstPage() end,
}

M["skim_next_chapter"] = {
    label    = _("Next chapter"),
    icon     = "\u{25B6}",
    category = "skim",
    callback      = function(ctx) ctx.skim.nextChapter() end,
    hold_callback = function(ctx) ctx.skim.lastPage() end,
}

M["skim_toc"] = {
    label    = _("Table of contents"),
    icon     = "\u{F0C9}",
    category = "skim",
    callback      = function(ctx) ctx.skim.showToc() end,
    hold_callback = function(ctx) ctx.skim.showBookMap() end,
}

M["skim_page"] = {
    label      = _("Page number"),
    icon       = "#", -- fallback only; icon_func below shows the live page number instead
    icon_func  = function(ctx) return tostring(ctx.skim.getCurrPage()) end,
    category   = "skim",
    callback      = function(ctx) ctx.skim.pageTap() end,
    hold_callback = function(ctx) ctx.skim.pageHold() end,
}

M["skim_prev_bookmark"] = {
    label    = _("Previous bookmark"),
    icon     = "\u{25C0}",
    category = "skim",
    callback = function(ctx) ctx.skim.prevBookmark() end,
}

M["skim_bookmark_toggle"] = {
    label     = _("Toggle bookmark"),
    icon      = "\u{F097}",
    icon_func = function(ctx) return ctx.skim.isBookmarked() and "\u{F02E}" or "\u{F097}" end,
    category  = "skim",
    callback      = function(ctx) ctx.skim.toggleBookmark() end,
    hold_callback = function(ctx) ctx.skim.showBookmark() end,
}

M["skim_next_bookmark"] = {
    label    = _("Next bookmark"),
    icon     = "\u{25B6}",
    category = "skim",
    callback = function(ctx) ctx.skim.nextBookmark() end,
}

-- Special pseudo-action: not a real action (no callback), rendered as the
-- actual page-progress slider widget instead of a button. Recognized by
-- `is_slider = true`, not by id, so it stays consistent even if the id
-- changes.
M["slider"] = {
    label     = _("Progress bar"),
    icon      = "\u{2194}",
    category  = "skim",
    is_slider = true,
}

return M
