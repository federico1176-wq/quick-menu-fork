-- Unified "skim as a grid" renderer.
--
-- Renders the whole skim area (progress bar + navigation) as a single
-- Actions-style grid: independent icons/labels, rows/columns, icon or
-- rectangle mode. Reuses the "skim" config section (items, layout knobs) and
-- the same select/sort action-manage machinery as Actions/Shortcuts.
--
-- The progress bar itself is just one more item in the list (id "slider" /
-- def.is_slider = true). Simplification: wherever it appears in the item
-- order, it always renders as its own full-width row (it can't usefully
-- share a row with fixed-size buttons), but its position among the other
-- rows is fully configurable via the item order / row pattern.

local Button          = require("ui/widget/button")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local VerticalGroup   = require("ui/widget/verticalgroup")
local VerticalSpan    = require("ui/widget/verticalspan")
local TextWidget      = require("ui/widget/textwidget")

local Font            = require("ui/font")
local Math            = require("optmath")
local UIManager       = require("ui/uimanager")

local ActionDefs      = require("action_defs")
local SkimActionDefs  = require("sections/skim_action_defs")
local SliderSection   = require("sections/slidersection")
local ActionButton    = require("widgets/actionbutton")
local ActionExec      = require("action_exec")
local Utils           = require("common/utils")
local ShadowDeco      = require("widgets/shadow_deco")
local Blitbuffer      = require("ffi/blitbuffer")

local SkimGrid = {}

local function getMergedDefs(config)
    local defs = ActionDefs.getMerged(config.custom_actions)
    for id, def in pairs(SkimActionDefs) do
        defs[id] = def
    end
    return defs
end

SkimGrid.getMergedDefs = getMergedDefs

-- @param ctx  table  plugin context
-- @param api  table  { skim = {curr_page, page_count}, goToPage, info_section }
--                     provided by sections/skimsection.lua
function SkimGrid.build(ctx, api)
    local config             = ctx.config
    local touch_menu         = ctx.touch_menu
    local reader              = ctx.reader
    local screen              = ctx.screen
    local inner_width         = ctx.inner_width
    local h_gap               = screen:scaleBySize(config.style.h_gap or 4)
    local action_size         = screen:scaleBySize(config.style.action_size or 64)
    local action_radius       = screen:scaleBySize(config.style.action_radius or 32)
    local btn_bordersize      = screen:scaleBySize(config.style.btn_bordersize or 1.5)
    local btn_radius          = screen:scaleBySize(config.style.btn_radius or 7)
    local btn_font_size       = config.style.btn_font_size or 16
    local slider_ticks_width  = screen:scaleBySize(config.style.slider_ticks_width or 1)
    local rect_btn_bordersize = screen:scaleBySize(config.style.rect_button_bordersize or 1.5)
    local rect_btn_bordercolor = Blitbuffer.gray(config.style.rect_button_border_intensity or 0)

    local section = Utils.getSection(config, "skim")
    if not section then return nil end
    section.items = section.items or {}

    local action_defs = getMergedDefs(config)

    local visible_actions = {}
    for _, id in ipairs(section.items) do
        local def = action_defs[id]
        if def and (not def.visible_func or def.visible_func(ctx)) then
            table.insert(visible_actions, { id = id, def = def })
        end
    end

    local num_actions = #visible_actions
    if num_actions == 0 then return nil end

    local row_gap = (section.row_gap and section.row_gap > 0) and screen:scaleBySize(section.row_gap) or screen:scaleBySize(config.style.v_gap or 4)
    local has_max_cols = section.max_cols and section.max_cols > 0

    local group = VerticalGroup:new{ align = "center" }
    local slider_refs = {}

    local function exec_action(action_data)
        if type(action_data) == "function" then
            action_data(ctx)
        elseif type(action_data) == "table" then
            touch_menu:closeMenu()
            UIManager:nextTick(function() ActionExec.dispatch(action_data) end)
        end
    end

    -- Builds the actual page-progress slider widget, sized to `width`.
    local function buildSliderWidget(width)
        local slider_btn_width = (api.info_section and api.info_section.slider_btn_width and api.info_section.slider_btn_width > 0)
            and screen:scaleBySize(api.info_section.slider_btn_width) or screen:scaleBySize(config.style.btn_width or 50)

        local row = SliderSection.build{
            touch_menu         = touch_menu,
            inner_width        = width,
            screen             = screen,
            btn_width          = slider_btn_width,
            max_width          = nil,
            btn_radius         = btn_radius,
            btn_bordersize     = btn_bordersize,
            btn_font_size      = btn_font_size,
            slider_ticks_width = slider_ticks_width,
            h_gap              = h_gap,
            min                = 1,
            max                = api.skim.page_count,
            get                = function() return api.skim.curr_page end,
            set                = api.goToPage,
            text_minus         = "\u{F056}",
            text_plus          = "\u{F055}",
            initial_pos_marker = true,
        }

        local progress = row.refs.sliders[1].widget
        progress.ticks              = reader.toc:getTocTicksFlattened()
        progress.tick_width         = slider_ticks_width
        progress.alt                = reader.document.flows
        progress.initial_percentage = (touch_menu.skim_orig_page or api.skim.curr_page) / api.skim.page_count

        table.insert(slider_refs, row.refs.sliders[1])
        return row.widget
    end

    -- ============================================================
    -- Rectangular mode: fixed columns, icon + label inline, row fills width
    -- ============================================================
    local function buildRectRow(entries, row_width)
        local rect_height = (section.rect_height and section.rect_height > 0) and screen:scaleBySize(section.rect_height) or nil
        local row = HorizontalGroup:new{ align = "center" }
        for j, entry in ipairs(entries) do
            if j > 1 then table.insert(row, HorizontalSpan:new{ width = h_gap }) end
            local def = entry.def
            local icon = def.icon_func and def.icon_func(ctx) or (def.icon or "")
            local label = def.label_func and def.label_func(ctx) or (def.label or "")
            local btn_text = section.show_label and (Utils.get_safe_icon(icon) .. " " .. label) or Utils.get_safe_icon(icon)
            table.insert(row, Button:new{
                text           = btn_text,
                width          = row_width,
                height         = rect_height,
                radius         = btn_radius,
                bordersize     = rect_btn_bordersize,
                background     = Blitbuffer.COLOR_WHITE,
                text_font_size = btn_font_size,
                show_parent    = touch_menu.show_parent,
                callback       = def.callback and function() exec_action(def.callback) end or nil,
                hold_callback  = def.hold_callback and function() exec_action(def.hold_callback) end or nil,
            })
            row[#row].frame.color = rect_btn_bordercolor
            ShadowDeco.attach(row[#row])
        end
        return row
    end

    -- ============================================================
    -- Icon mode: square/circle icon buttons, optional label below/inside
    -- ============================================================
    local action_radius_ratio = action_radius / action_size
    local action_icon_size    = math.floor(action_size * 0.4 + 0.5)
    local action_label_size   = (section.label_size and section.label_size > 0) and section.label_size
        or math.floor(action_size * 0.18 + 0.5)

    local function buildIconRow(entries, btn_size)
        local btn_radius2 = math.floor(btn_size * action_radius_ratio)
        local row = HorizontalGroup:new{ align = "center" }
        for j, entry in ipairs(entries) do
            if j > 1 then table.insert(row, HorizontalSpan:new{ width = h_gap }) end
            local def = entry.def
            local label_text = section.show_label and (def.label_func and def.label_func(ctx) or def.label) or nil
            local label_inside = section.label_inside and label_text

            local btn = ActionButton:new{
                icon          = def.icon_func and def.icon_func(ctx) or (def.icon or ""),
                width         = btn_size,
                height        = btn_size,
                radius        = btn_radius2,
                icon_size     = math.floor(btn_size * 0.4 + 0.5),
                bordersize    = btn_bordersize,
                is_active     = def.active_func and def.active_func(ctx) or false,
                callback      = def.callback and function() exec_action(def.callback) end or nil,
                hold_callback = def.hold_callback and function() exec_action(def.hold_callback) end or nil,
                label         = label_inside and label_text or nil,
                label_face    = label_inside and Font:getFace("cfont", action_label_size) or nil,
            }

            if label_text and not label_inside then
                table.insert(row, VerticalGroup:new{
                    align = "center",
                    btn,
                    TextWidget:new{
                        text = label_text,
                        face = Font:getFace("cfont", action_label_size),
                        max_width = btn_size,
                    }
                })
            else
                table.insert(row, btn)
            end
        end
        return row
    end

    -- ============================================================
    -- Row-by-row layout: "slider" (if present) always gets its own
    -- full-width row; everything else groups into rows per row_pattern
    -- (or max_cols / all-in-one-row when no custom pattern is set).
    -- ============================================================
    local i = 1
    local pattern_i = 1

    while i <= num_actions do
        local entry = visible_actions[i]

        if entry.def.is_slider then
            table.insert(group, buildSliderWidget(inner_width))
            i = i + 1
        else
            local wanted
            if section.custom_rows and section.row_pattern and #section.row_pattern > 0 then
                wanted = section.row_pattern[pattern_i] or (has_max_cols and section.max_cols) or (num_actions - i + 1)
                pattern_i = pattern_i + 1
            else
                wanted = has_max_cols and section.max_cols or (num_actions - i + 1)
            end

            local row_entries = {}
            local j = i
            while j <= num_actions and #row_entries < wanted do
                local e = visible_actions[j]
                if e.def.is_slider then break end -- never cross into the slider item
                table.insert(row_entries, e)
                j = j + 1
            end

            local n = #row_entries
            if n > 0 then
                if section.rect_ctrl then
                    local row_width = Math.round((inner_width - h_gap * (n - 1)) / n)
                    table.insert(group, buildRectRow(row_entries, row_width))
                else
                    local computed_fit = math.floor((inner_width - (n - 1) * h_gap) / n)
                    local btn_size = math.min(action_size, computed_fit)
                    table.insert(group, buildIconRow(row_entries, btn_size))
                end
            end
            i = j
        end

        if i <= num_actions then
            table.insert(group, VerticalSpan:new{ width = row_gap })
        end
    end

    return {
        widget = group,
        refs = { sliders = slider_refs },
    }
end

return SkimGrid
