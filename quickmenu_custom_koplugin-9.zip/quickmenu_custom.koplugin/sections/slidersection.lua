local Button          = require("ui/widget/button")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local ProgressWidget  = require("ui/widget/progresswidget")
local CenterContainer = require("ui/widget/container/centercontainer")
local Geom            = require("ui/geometry")
local UIManager        = require("ui/uimanager")

local SliderSection = {}

function SliderSection.buildTicks(min, max, count)
    local ticks = {}
    local range = max - min
    for i = 1, count - 1 do
        table.insert(ticks, math.floor(range * i / count + 0.5))
    end
    return ticks
end

function SliderSection.build(opts)
    -- opts import
    local touch_menu         = opts.touch_menu
    local screen             = opts.screen
    local inner_width        = opts.inner_width
    local btn_width          = opts.btn_width or screen:scaleBySize(50)
    local h_gap              = opts.h_gap or screen:scaleBySize(4)
    local btn_radius         = opts.btn_radius or screen:scaleBySize(7)
    local btn_font_size      = opts.btn_font_size or 16
    local btn_bordersize     = opts.btn_bordersize or screen:scaleBySize(1.5)
    local slider_ticks_width = opts.slider_ticks_width or screen:scaleBySize(1)

    -- opts.max_width (optional): caps the whole row (buttons + bar) below
    -- inner_width; the row is then centered within inner_width.
    local row_width = inner_width
    if opts.max_width and opts.max_width > 0 then
        row_width = math.min(inner_width, opts.max_width)
    end

    -- logic
    local progress

    local function getValue() return opts.get() end

    -- A full touch_menu:updateItems() rebuild on every single tap/step (the
    -- old behaviour) is what caused the visible stutter/freeze when mashing
    -- the +/- buttons: each rebuild recalculates and repaints the whole
    -- panel. Now the bar fill updates immediately with a cheap targeted
    -- repaint, and the full rebuild (needed for any live label elsewhere,
    -- e.g. "Frontlight : NN") is debounced so a burst of taps only triggers
    -- one rebuild shortly after the user stops, instead of one per tap.
    local pending_refresh = false
    local function scheduleMenuRefresh()
        if not (touch_menu and touch_menu.updateItems) then return end
        if pending_refresh then return end
        pending_refresh = true
        UIManager:scheduleIn(0.3, function()
            pending_refresh = false
            touch_menu:updateItems(1)
        end)
    end

    local function setValue(value)
        value = math.max(opts.min, math.min(opts.max, value))
        opts.set(value)

        if progress then
            local range = opts.max - opts.min
            local pct = (range > 0) and ((value - opts.min) / range) or 0
            progress:setPercentage(pct)
            if progress.dimen and touch_menu then
                UIManager:setDirty(touch_menu.show_parent, "ui", progress.dimen)
            end
        end

        -- immediate, cheap hook for consumers that want to reflect the new
        -- value right away (e.g. the light toggle button), without waiting
        -- for the debounced full panel rebuild below
        if opts.on_change then opts.on_change(value) end

        scheduleMenuRefresh()
    end

    -- widgets
    local minus = Button:new{
        text           = opts.text_minus or "−",
        width          = btn_width,
        height         = opts.height,
        radius         = btn_radius,
        bordersize     = btn_bordersize,
        text_font_size = btn_font_size,
        show_parent    = touch_menu.show_parent,
        callback       = opts.minus_callback or function() setValue(getValue() - (opts.step or 1)) end,
        hold_callback  = opts.minus_hold_callback or function() setValue(opts.min) end,
    }

    progress = ProgressWidget:new{
        width              = row_width - 2 * btn_width - 2 * h_gap,
        height             = minus:getSize().h,
        radius             = btn_radius,
        bordersize         = btn_bordersize,
        percentage         = (getValue() - opts.min) / (opts.max - opts.min),
        ticks              = opts.ticks,
        tick_width         = slider_ticks_width,
        last               = opts.max,
        initial_pos_marker = opts.initial_pos_marker,
    }

    local plus = Button:new{
        text           = opts.text_plus or "+",
        width          = btn_width,
        height         = opts.height,
        radius         = btn_radius,
        bordersize     = btn_bordersize,
        text_font_size = btn_font_size,
        show_parent    = touch_menu.show_parent,
        callback       = opts.plus_callback or function() setValue(getValue() + (opts.step or 1)) end,
        hold_callback  = opts.plus_hold_callback or function() setValue(opts.max) end,
    }

    -- group
    local row = HorizontalGroup:new{
        align = "center",
        minus,
        HorizontalSpan:new{ width = h_gap },
        progress,
        HorizontalSpan:new{ width = h_gap },
        plus,
    }

    local final_widget = row
    if row_width < inner_width then
        final_widget = CenterContainer:new{
            dimen = Geom:new{ w = inner_width, h = row:getSize().h },
            row
        }
    end

    -- refs
    local refs = { buttons = {}, sliders = {}, widgets = {} }
    table.insert(refs.sliders, {
        widget = progress,
        get    = getValue,
        set    = setValue,
        min    = opts.min,
        max    = opts.max,
    })

    return { widget = final_widget, refs = refs }
end

return SliderSection
