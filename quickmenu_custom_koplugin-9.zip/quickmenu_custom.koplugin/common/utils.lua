local M = {}

local VerticalGroup = require("ui/widget/verticalgroup")
local TextWidget     = require("ui/widget/textwidget")
local Font           = require("ui/font")
local _              = require("common/i18n").gettext

--- Wraps a slider widget with a centered caption below it, styled like a
--- button label (used for the "show label on brightness bar" option so the
--- frontlight slider can show "Frontlight" under the bar, same as a button
--- caption). Returns the widget unchanged if the section doesn't request it.
--- @param widget table  The slider widget (or row) to wrap.
--- @param section table The section settings table (expects show_slider_label).
--- @param font_size number Base font size to derive the caption size from.
--- @return table         The original widget, or a VerticalGroup with caption.
function M.attachSliderLabel(widget, section, font_size)
    if not section or not section.show_slider_label then return widget end
    local label_size = math.max(10, math.floor((font_size or 16) * 0.8))
    return VerticalGroup:new{
        align = "center",
        widget,
        TextWidget:new{
            text = _("Frontlight"),
            face = Font:getFace("cfont", label_size),
        }
    }
end


--- Convertit une valeur native en pourcentage (0-100).
--- @param val number La valeur actuelle (ex: nl.cur).
--- @param min number La valeur minimale (ex: nl.min).
--- @param max number La valeur maximale (ex: nl.max).
--- @return number Le pourcentage arrondi (0-100).
function M.get_percentage(val, min, max)
    if not val or not min or not max or (max - min) == 0 then return 0 end
    local percent = ((val - min) / (max - min)) * 100
    return math.floor(percent + 0.5) -- +0.5 pour un arrondi correct
end

--- Normalizes a string by removing accents for sorting purposes.
--- @param str string The string to normalize.
--- @return string     The normalized string.
function M.normalize_for_sort(str)
    local replacements = {
        ["à"] = "a", ["á"] = "a", ["â"] = "a", ["ã"] = "a", ["ä"] = "a",
        ["è"] = "e", ["é"] = "e", ["ê"] = "e", ["ë"] = "e",
        ["ì"] = "i", ["í"] = "i", ["î"] = "i", ["ï"] = "i",
        ["ò"] = "o", ["ó"] = "o", ["ô"] = "o", ["õ"] = "o", ["ö"] = "o",
        ["ù"] = "u", ["ú"] = "u", ["û"] = "u", ["ü"] = "u",
        ["ñ"] = "n", ["ç"] = "c",
        ["À"] = "a", ["Á"] = "a", ["Â"] = "a", ["Ã"] = "a", ["Ä"] = "a",
        ["È"] = "e", ["É"] = "e", ["Ê"] = "e", ["Ë"] = "e",
        ["Ì"] = "i", ["Í"] = "i", ["Î"] = "i", ["Ï"] = "i",
        ["Ò"] = "o", ["Ó"] = "o", ["Ô"] = "o", ["Õ"] = "o", ["Ö"] = "o",
        ["Ù"] = "u", ["Ú"] = "u", ["Û"] = "u", ["Ü"] = "u",
        ["Ñ"] = "n", ["Ç"] = "c"
    }

    local s = str
    for char, replacement in pairs(replacements) do
        s = s:gsub(char, replacement)
    end
    return s:lower() -- return lower normalized string
end

--- Sorts a list of tables based on a specific field.
--- @param list             table   The table to sort.
--- @param field            string  The key to sort by.
--- @param case_insensitive boolean? Sort ignoring case (default: true).
--- @param normalize        boolean? Use accent-free normalization (default: false).
function M.sort_by_field(list, field, case_insensitive, normalize)
    if case_insensitive == nil then case_insensitive = true end

    table.sort(list, function(a, b)
        local val_a = a[field] or ""
        local val_b = b[field] or ""

        -- Si on veut normaliser, on applique la fonction de nettoyage
        if normalize then
            val_a = M.normalize_for_sort(val_a)
            val_b = M.normalize_for_sort(val_b)
        elseif case_insensitive then
            -- Sinon, on fait juste une mise en minuscule simple
            val_a = val_a:lower()
            val_b = val_b:lower()
        end

        return val_a < val_b
    end)
end

--- Checks if a value exists within a table.
--- @param tbl  table  The table to search in.
--- @param val  any    The value to look for.
--- @return     boolean True if the value is found, false otherwise.
function M.table_contains(tbl, val)
    for i, v in ipairs(tbl) do
        if v == val then return true end
    end
    return false
end

--- Removes the first occurrence of a value from a table.
--- @param tbl  table  The table to modify.
--- @param val  any    The value to remove.
--- @return     boolean True if the value was found and removed, false otherwise.
function M.table_remove(tbl, val)
    for i, v in ipairs(tbl) do
        if v == val then
            table.remove(tbl, i)
            return true
        end
    end
    return false
end

--- Inserts a value into a table only if it does not already exist.
--- @param tbl   table  The table to modify.
--- @param val   any    The value to insert.
--- @return      boolean True if the value was inserted, false if it already existed.
function M.table_insert_unique(tbl, val)
    if not tbl then return false end
    for i, v in ipairs(tbl) do
        if v == val then
            return false
        end
    end
    table.insert(tbl, val)
    return true
end

--- Wraps each item in a flat list into an individual table.
--- This transformation converts a flat array of items into a nested structure
--- (e.g., { {item1}, {item2}, ... }), which is often required for specific
--- UI containers or menu layouts in KOReader.
---
--- @param items table  The original flat array of tables.
--- @return table       A new array where each original item is encapsulated
---                     within its own table.
function M.wrap_items(items)
    local wrapped = {}
    for i = 1, #items do
        wrapped[i] = { items[i] }
    end
    return wrapped
end

--- Unwraps a nested list of items into a flat array.
--- This transformation converts a nested structure (e.g., { {item1}, {item2}, ... })
--- back into a flat array of items.
---
--- @param wrapped_items table  The original nested array of tables.
--- @return table               A new flat array where each item is extracted
---                             from its encapsulating table.
function M.unwrap_items(wrapped_items)
    local unwrapped = {}
    for i = 1, #wrapped_items do
        -- On extrait l'élément contenu dans la sous-table
        unwrapped[i] = wrapped_items[i][1]
    end
    return unwrapped
end

--- Transforms an icon string into a safe, displayable format.
--- If the provided icon string matches the internal SVG reference format
--- (e.g., "[icon=name]"), it is replaced with a default Unicode character.
--- Otherwise, the original icon string is returned.
---
--- @param icon_str string The original icon string or SVG path reference.
--- @return string         A safe Unicode icon or the original string if valid.
function M.get_safe_icon(icon_str)
    if not icon_str or icon_str == "" then  return "\u{F059}"  end
    local extracted_icon = icon_str:match("^%[icon=(.+)%]$")
    if extracted_icon then return "\u{F059}" end
    return icon_str
end

--- Render a preview image (BlitBuffer) of a given page without changing the
--- current reading position. Best-effort: different document engines (crengine
--- / mupdf / djvu) expose slightly different renderPage signatures across
--- KOReader versions, so this tries the common ones and returns nil (never
--- raises) if none work, letting the caller fall back gracefully.
--- @param document table  reader.document
--- @param pageno   number page to render
--- @param w        number target width in pixels
--- @param h        number target height in pixels
--- @return          userdata|nil  A BlitBuffer scaled to w x h, or nil
function M.renderPagePreview(document, pageno, w, h)
    if not document or not pageno or not w or not h or w <= 0 or h <= 0 then return nil end

    local zoom = 1
    local ok_dim, dim = pcall(function() return document:getNativePageDimensions(pageno) end)
    if ok_dim and dim and dim.w and dim.h and dim.w > 0 and dim.h > 0 then
        zoom = math.min(w / dim.w, h / dim.h)
    end

    local bb
    local ok1, tile1 = pcall(function()
        return document:renderPage(pageno, nil, zoom, 0, 0, document.render_mode)
    end)
    if ok1 and tile1 and tile1.bb then bb = tile1.bb end

    if not bb then
        local ok2, tile2 = pcall(function()
            return document:renderPage(pageno, nil, zoom, 0)
        end)
        if ok2 and tile2 and tile2.bb then bb = tile2.bb end
    end

    if not bb then return nil end

    local RenderImage = require("ui/renderimage")
    local ok3, scaled = pcall(function() return RenderImage:scaleBlitBuffer(bb, w, h, true) end)
    if ok3 and scaled then return scaled end
    return bb
end

--- Builds a list of per-row item counts covering `total` items.
--- If `pattern` (array of positive ints, e.g. {2, 3}) is given, rows follow
--- that pattern in order. Any items left over once the pattern is exhausted
--- are chunked using `fallback_cols` (0/nil/absent = a single row with all
--- the remaining items). If the pattern itself covers more than `total`,
--- extra pattern rows are simply not reached.
--- @param total         number    total number of visible items
--- @param pattern       table|nil array of per-row counts, e.g. {2, 3}
--- @param fallback_cols number|nil column count for any leftover items
--- @return table  array of per-row counts, e.g. {2, 3, 3}
function M.buildRows(total, pattern, fallback_cols)
    local rows = {}
    local remaining = total

    if pattern and #pattern > 0 then
        for _, n in ipairs(pattern) do
            if remaining <= 0 then break end
            local take = math.min(math.max(1, n), remaining)
            table.insert(rows, take)
            remaining = remaining - take
        end
    end

    if remaining > 0 then
        local chunk = (fallback_cols and fallback_cols > 0) and fallback_cols or remaining
        while remaining > 0 do
            local take = math.min(chunk, remaining)
            table.insert(rows, take)
            remaining = remaining - take
        end
    end

    return rows
end

--- Shows a dialog to edit a section's custom row pattern (how many
--- icons/buttons appear on each row, e.g. row 1 = 2, row 2 = 3).
--- Edits a working copy so "Cancelar" reverts cleanly; "Aplicar" writes
--- section.row_pattern and saves. Closes and reopens the dialog on every
--- structural change (add/remove row) since ButtonDialog's button grid is
--- fixed at construction time.
--- @param ctx         table    plugin context (ctx.config, ctx.touch_menu)
--- @param section_id  string   section id, e.g. "actions" or "shortcuts"
--- @param on_close    function|nil called after the dialog closes (Apply or Cancel)
function M.showRowPatternEditor(ctx, section_id, on_close)
    local ButtonDialog = require("ui/widget/buttondialog")
    local UIManager    = require("ui/uimanager")
    local Config        = require("config")
    local _              = require("common/i18n").gettext

    local config  = ctx.config
    local section = M.getSection(config, section_id)
    if not section then return end

    local working = {}
    for i, v in ipairs(section.row_pattern or {}) do working[i] = v end

    local dialog

    local function rebuild()
        if dialog then UIManager:close(dialog) end

        local buttons = {}

        for i, count in ipairs(working) do
            table.insert(buttons, {
                { text = tostring(i) .. ")", enabled = false },
                { text = "-1", callback = function()
                    working[i] = math.max(1, working[i] - 1)
                    rebuild()
                end },
                { text = tostring(count), enabled = false },
                { text = "+1", callback = function()
                    working[i] = math.min(15, working[i] + 1)
                    rebuild()
                end },
                { text = "\u{2715}", callback = function()
                    table.remove(working, i)
                    rebuild()
                end },
            })
        end

        table.insert(buttons, {
            { text = _("+ Add row"), callback = function()
                table.insert(working, 2)
                rebuild()
            end },
        })

        table.insert(buttons, {
            { text = _("Cancel"), callback = function()
                UIManager:close(dialog)
                if on_close then on_close() end
            end },
            { text = _("Clear"), callback = function()
                working = {}
                rebuild()
            end },
            { text = _("Apply"), is_enter_default = true, callback = function()
                section.row_pattern = working
                Config.saveAndRefresh(ctx)
                UIManager:close(dialog)
                if on_close then on_close() end
            end },
        })

        dialog = ButtonDialog:new{
            dismissable = false,
            title = _("Icons per row") .. " (" .. _("e.g.") .. " 2, 3)",
            title_align = "left",
            buttons = buttons,
            tap_close_callback = function()
                if on_close then on_close() end
            end,
        }
        UIManager:show(dialog)
    end

    rebuild()
end

--- Find a section by its ID within the config table.
--- @param config table  The configuration table containing sections.
--- @param id     string  The section ID to look for.
--- @return        table|nil
function M.getSection(config, id)
    if not config or type(config.sections) ~= "table" then
        return nil
    end
    local section = config.sections[id]
    if section then
        section.items = section.items or {}
    end
    return section
end

--- Reset a section to defaults.
--- @param section  table  The section current settings.
--- @param defaults table  The section defaults settings.
function M.resetSectionToDefaults(section, defaults)
    if not section or not defaults then return end
    for k in pairs(section) do
        section[k] = nil
    end
    for k, v in pairs(defaults) do
        if type(v) == "table" then
            section[k] = {}
            for key, val in pairs(v) do
                section[k][key] = val
            end
        else
            section[k] = v
        end
    end
end

--- Verify plugin in present in active instance.
--- @param slot      string  plugin name
--- @return          boolean
function M.hasPlugin(slot)
    local ok_f, FM = pcall(require, "apps/filemanager/filemanager")
    local ok_r, RU = pcall(require, "apps/reader/readerui")
    local ui = (ok_f and FM.instance) or (ok_r and RU.instance)
    return ui == nil or ui[slot] ~= nil
end

--- Resolve an icon name to an absolute file path (checks .svg then .png).
--- @param icons_dir string  absolute path ending with "/"
--- @param name      string  icon name without extension
--- @return          string|nil
function M.resolveLocalIcon(icons_dir, name)
    if not icons_dir or not name then return nil end
    local lfs = require("libs/libkoreader-lfs")
    for _, ext in ipairs({ ".svg", ".png" }) do
        local p = icons_dir .. name .. ext
        if lfs.attributes(p, "mode") == "file" then return p end
    end
    return nil
end

--- Register plugin icons so short names resolve via IconWidget at runtime.
--- Optionally copies files to the user icons dir for cold-start resolution.
---
--- @param icons_dir        string   absolute path to the plugin icons dir, ending with "/"
--- @param icons            table    { [icon_name] = "filename.ext", ... }
--- @param copy_to_user_dir boolean  also copy files to DataStorage icons dir
function M.registerPluginIcons(icons_dir, icons, copy_to_user_dir)
    if not icons_dir or type(icons) ~= "table" then return end
    pcall(function()
        local lfs = require("libs/libkoreader-lfs")
        local user_icons_dir =  nil

        if copy_to_user_dir then
            pcall(function()
                local DataStorage = require("datastorage")
                local ffiutil = require("ffi/util")
                local user_icons_dir = DataStorage:getDataDir() .. "/icons"
                if lfs.attributes(user_icons_dir, "mode") ~= "directory" then
                    lfs.mkdir(user_icons_dir)
                end
                for name, filename in pairs(icons) do
                    -- Use icon short-name as dest so ICONS_DIRS lookup finds it by name
                    local ext = filename:match("%.[^%.]+$") or ".svg"
                    local dst = user_icons_dir .. "/" .. name .. ext
                    if lfs.attributes(dst, "mode") ~= "file" then
                        local src = icons_dir .. filename
                        if lfs.attributes(src, "mode") == "file" then
                            ffiutil.copyFile(src, dst)
                        end
                    end
                end
            end)
        end

        -- Inject into IconWidget's runtime upvalue caches
        local iw = require("ui/widget/iconwidget")
        local iw_init = rawget(iw, "init")
        if type(iw_init) ~= "function" then return end
        local icons_path, icons_dirs
        for i = 1, 64 do
            local uname, uval = debug.getupvalue(iw_init, i)
            if uname == nil then break end
            if uname == "ICONS_PATH" and type(uval) == "table" then
                icons_path = uval
            elseif uname == "ICONS_DIRS" and type(uval) == "table" then
                icons_dirs = uval
            end
            if icons_path and icons_dirs then break end
        end
        -- Ensure user icons dir is in ICONS_DIRS (may have been absent at widget load time)
        if icons_dirs and copy_to_user_dir then
            pcall(function()
                local DataStorage = require("datastorage")
                local user_dir = DataStorage:getDataDir() .. "/icons"
                local found = false
                for _, d in ipairs(icons_dirs) do
                    if d == user_dir then found = true; break end
                end
                if not found then table.insert(icons_dirs, 1, user_dir) end
            end)
        end
        if not icons_path then return end
        for name, filename in pairs(icons) do
            if not icons_path[name] then
                local user_p = user_icons_dir and M.resolveLocalIcon(user_icons_dir, name) or nil
                if user_p then
                    icons_path[name] = user_p
                else
                    local p = icons_dir .. filename
                    if lfs.attributes(p, "mode") == "file" then
                        icons_path[name] = p
                    end
                end
            end
        end
    end)
end

--- Fetches current system resource metrics (CPU, RAM, and Storage).
--- Reads data from system files (/proc/stat, /proc/meminfo) and executes
--- shell commands (df) to determine usage statistics.
---
--- @return table  A table containing the following fields:
---                 - cpu: {used, usedp, available, availablep, total}
---                 - memory: {total, free, available, used, usedp, availablep}
---                 - storage: {available, availablep, used, usedp, total}
function M.systemInfo()
    local util = require("util")
    local Device = require("device")
    local result = {}
    do
        local stat = io.open("/proc/stat", "r")
        if stat ~= nil then
            for line in stat:lines() do
                local t = util.splitToArray(line, " ")
                if #t >= 5 and string.lower(t[1]) == "cpu" then
                    local n1, n2, n3, n4
                    n1 = tonumber(t[2]) -- user
                    n2 = tonumber(t[3]) -- nice
                    n3 = tonumber(t[4]) -- system
                    n4 = n1 + n2 + n3 -- used
                    n5 = tonumber(t[5]) -- available
                    n6 = n4 + n5 -- total
                    if n4 ~= nil and n5 ~= nil and n6 ~= nil and n6 ~= 0 then
                        result.cpu = {
                            used = n4,
                            usedp = math.floor((n4 * 100) / n6),
                            available = n5,
                            availablep = math.floor((n5 * 100) / n6),
                            total = n6,
                        }
                        break
                    end
                end
            end
            stat:close()
        end
    end

    do
        local meminfo = io.open("/proc/meminfo", "r")
        if meminfo ~= nil then
            result.memory = {}
            for line in meminfo:lines() do
                local t = util.splitToArray(line, " ")
                if #t >= 2 then
                    if string.lower(t[1]) == "memtotal:" then
                        local n = tonumber(t[2])
                        if n ~= nil then
                            result.memory.total = n
                        end
                    elseif string.lower(t[1]) == "memfree:" then
                        local n = tonumber(t[2])
                        if n ~= nil then
                            result.memory.free = n
                        end
                    elseif string.lower(t[1]) == "memavailable:" then
                        local n = tonumber(t[2])
                        if n ~= nil then
                            result.memory.available = n
                        end
                    end
                end
            end
            meminfo:close()

            if result.memory.total and result.memory.available then
                result.memory.used = result.memory.total - result.memory.available
                if result.memory.total > 0 then
                    result.memory.usedp = math.floor((result.memory.used * 100) / result.memory.total)
                    result.memory.availablep = math.floor((result.memory.available * 100) / result.memory.total)
                end
            end
        end
    end

    do
        local storage_filter = nil
        if Device:isCervantes() or Device:isPocketBook() then
            storage_filter = "mmcblk"
        elseif Device:isKobo() then
            storage_filter = " /mnt/"
        elseif Device:isKindle() then
            storage_filter = "' /mnt/us$'"
        elseif Device:isSDL() then
            storage_filter = "/dev/sd"
        end

        if storage_filter then
            local std_out = io.popen("df -k | sed -r 's/ +/ /g' | grep " .. storage_filter .. " | sed 's/ /\\t/g' | cut -f 2,4,5,6")
            if std_out then
                result.storage = {}
                for line in std_out:lines() do
                    local t = util.splitToArray(line, "\t")
                    if #t == 4 then
                        local n1, n2, n3, n4
                        n1 = tonumber(t[1]) --total kB
                        n2 = tonumber(t[2]) --available kB
                        -- t[3]: usedpercentage
                        -- t[4]: mountpoint
                        if n1 ~= nil and n2 ~= nil and n1 ~= 0 then
                        result.storage = {
                            available = n2,
                            availablep = math.floor((n2 * 100) / n1),
                            used = n1 - n2,
                            usedp = math.floor(((n1 - n2) * 100) / n1),
                            total = n1,
                        }
                        break
                        end
                    end
                end
            end
            std_out:close()
        end
    end

    return result
end

--- Ordered list of the visual slider styles supported by widgets/zen_slider.lua
--- (ported from neo_quicksetting's NeoSlider). Used by the Frontlight/Warmth
--- settings menu to let the user cycle through and pick a style.
--- @return table Array of { id = "style_id", label = "Translated label" }.
function M.getSliderStyles()
    local _ = require("common/i18n").gettext
    return {
        { id = "neo",            label = _("Neo (Rounded Knob)") },
        { id = "progress_bar",   label = _("Progress Bar") },
        { id = "notched",        label = _("Notched Bar") },
        { id = "square_notched", label = _("Square Notched") },
        { id = "outline",        label = _("Outline") },
        { id = "fader",          label = _("Fader") },
        { id = "dots",           label = _("Dots") },
        { id = "cyber",          label = _("Cyber Bar") },
        { id = "retro",          label = _("Retro Switch") },
        { id = "split_rail",     label = _("Split Rail") },
        { id = "stepped_bars",   label = _("Stepped Bars") },
        { id = "fluid_pill",     label = _("Fluid Pill") },
        { id = "battery",        label = _("Battery Indicator") },
        { id = "piano",          label = _("Piano Keys") },
    }
end

--- Returns the label for a given style id (falls back to the id itself).
--- @param style_id string
--- @return string
function M.getSliderStyleLabel(style_id)
    for _, s in ipairs(M.getSliderStyles()) do
        if s.id == style_id then return s.label end
    end
    return style_id
end

--- Returns the next style id in the list after `current` (wraps around).
--- @param current string Current style id.
--- @return string Next style id.
function M.nextSliderStyle(current)
    local styles = M.getSliderStyles()
    for i, s in ipairs(styles) do
        if s.id == current then
            local nxt = styles[i + 1] or styles[1]
            return nxt.id
        end
    end
    return styles[1].id
end

--- Builds a debounced "reload" callback for settings dialogs (Settings
--- ButtonDialogs re-run checked_func/text_func on every redraw, and each of
--- those wants the live quick-menu panel kept in sync behind it). Calling
--- touch_menu:updateItems() straight from there is expensive: it rebuilds
--- the whole panel (icons, cover thumbnails, action scans, etc.), so a
--- string of toggles tapped quickly -- or the dialog simply redrawing
--- itself repeatedly -- could trigger one heavy rebuild after another and
--- make the UI visibly stutter or lock up for a moment. This coalesces any
--- burst of calls into a single rebuild on the next UI tick, so the panel
--- still updates live without blocking the current tap's own feedback.
--- @param ctx table The section ctx (needs ctx.touch_menu)
--- @return function reload   call this from checked_func/text_func as before
--- @return function activate call this once the dialog has finished its
---                            initial render, to allow reload() to fire
function M.debouncedReload(ctx)
    local UIManager = require("ui/uimanager")
    local is_initializing = true
    local pending = false
    local function reload()
        if is_initializing or pending then return end
        local touch_menu = ctx.touch_menu
        if not (touch_menu and touch_menu.updateItems) then return end
        pending = true
        UIManager:nextTick(function()
            pending = false
            if touch_menu.updateItems then touch_menu:updateItems() end
        end)
    end
    local function activate() is_initializing = false end
    return reload, activate
end

return M
