local DataStorage = require("datastorage")
local LuaSettings = require("luasettings")
local UIManager   = require("ui/uimanager")

local SETTINGS_PATH = DataStorage:getSettingsDir() .. "/quick_menu_settings.lua"
local _settings = LuaSettings:open(SETTINGS_PATH)

local Config = {}

Config.DEFAULTS = {
    section_order = { "actions", "frontlight", "shortcuts", "info", "toc", "pagebrowser", "footer" },
    sections = {
        actions = {
            enabled_f = true,
            enabled_r = true,
            collapse = false,
            show_title = true,
            show_label = true,
            fit_ctrl = true,
            stretch_ctrl = false, -- icon mode: grow buttons to fill the row width, like rect mode
            justified_ctrl = true,
            rect_ctrl = false, -- botones rectangulares con columnas fijas (como Shortcuts)
            max_cols = 0, -- 0 = auto (ancho disponible)
            rect_height = 0, -- alto fijo de los botones en modo rectángulo, 0 = auto
            row_gap = 0, -- separación vertical entre filas, 0 = usa el valor global (config.style.v_gap)
            custom_rows = false, -- usar row_pattern en vez de max_cols
            row_pattern = {}, -- cantidad de iconos/botones por fila, ej. {2, 3}
            label_size = 0, -- tamaño (pt) de la etiqueta en modo ícono, 0 = auto
            label_inside = false, -- mostrar la etiqueta dentro del recuadro del ícono (el recuadro crece)
            items = { "wifi", "night", "light", "rotate", "lock", "usb", "power" }
        },
        frontlight = {
            enabled_f = true,
            enabled_r = true,
            collapse = false,
            show_title = true,
            use_zenslider = false,
            slider_style = "neo", -- estilo visual de la barra (solo aplica con use_zenslider = true)
            show_toggle_buttons = true,
            toggle_buttons_side = "left", -- "left" or "right"
            show_toggle_labels = true, -- mostrar etiquetas (Luz/Día/Noche) bajo los botones de luz/noche
            show_slider_label = false, -- mostrar etiqueta "Luz frontal" junto a la barra de brillo
            slider_btn_width = 0, -- 0 = usa el ancho global de botones (config.style.btn_width)
            slider_max_width = 0, -- 0 = sin límite (ocupa todo el ancho disponible)
        },
        shortcuts = {
            enabled_f = true,
            enabled_r = false,
            collapse = false,
            show_title = true,
            show_label = true,
            icon_ctrl = false, -- estilo Actions: icono + etiqueta apilados, tamaño cuadrado/circular
            fit_ctrl = true,
            stretch_ctrl = false, -- icon mode: grow buttons to fill the row width, like rect mode
            justified_ctrl = true,
            max_cols = 3,
            rect_height = 0, -- alto fijo de los botones en modo botón (no icon_ctrl), 0 = auto
            row_gap = 0, -- separación vertical entre filas, 0 = usa el valor global (config.style.v_gap)
            custom_rows = false, -- usar row_pattern en vez de max_cols
            row_pattern = {}, -- cantidad de iconos/botones por fila, ej. {2, 3}
            label_size = 0, -- tamaño (pt) de la etiqueta en modo ícono, 0 = auto
            label_inside = false, -- mostrar la etiqueta dentro del recuadro del ícono (el recuadro crece)
            items = { "history", "collections", "statistics", "search", "dictionary", "cloud" }
        },
        info = {
            enabled_r = true,
            show_title = true,
            collapse = false,
            show_thumbnail = true,
            show_skim = true,
            cover_side = "left", -- "left" or "right"
            thumbnail_mode = "cover", -- "cover" or "preview" (live page preview)
            page_tap_action = {},  -- {} = comportamiento por defecto (Ir a página)
            page_hold_action = {}, -- {} = comportamiento por defecto (Volver a la página anterior)
            slider_btn_width = 0, -- 0 = usa el ancho global de botones (config.style.btn_width)
            slider_max_width = 0, -- 0 = sin límite (ocupa todo el ancho disponible)
            skim_grid_mode = false, -- false = barra + fila de navegación por defecto, true = grilla personalizable "skim" (estilo Actions)
            show_info_text = true, -- mostrar el bloque título/autor/capítulo
            title_font = false, -- false = usa la fuente de la UI (cfont); si no, nombre de archivo de fuente elegido
            title_font_size = 0, -- 0 = usa el tamaño global de botones (config.style.btn_font_size)
            author_font = false,
            author_font_size = 0,
            chapter_font = false,
            chapter_font_size = 0,
            section_height = 0, -- alto fijo (px) para toda la sección Reading; 0 = auto/sin límite
        },
        -- Grilla personalizable que sustituye TODA el área de skim (barra de progreso +
        -- fila de navegación) cuando info.skim_grid_mode = true. Se comporta como la
        -- sección "actions" (mismo motor de filas/columnas, modo ícono o rectángulo,
        -- tamaño de etiqueta, etc.) y comparte selector/ordenador de acciones.
        -- Los ítems pueden ser cualquier acción genérica de Accesos Rápidos, una acción
        -- propia de skim (capítulo/TOC/página/marcador, ver sections/skim_action_defs.lua)
        -- o "slider" (la barra de progreso en sí). "slider" siempre ocupa su propia fila
        -- completa, sin importar en qué posición de la lista esté.
        skim = {
            show_label = false,
            rect_ctrl = false, -- false = íconos, true = botones rectangulares (como Actions)
            max_cols = 0, -- 0 = auto
            rect_height = 0, -- alto fijo en modo rectángulo, 0 = auto
            row_gap = 0, -- 0 = usa el valor global (config.style.v_gap)
            custom_rows = true, -- usar row_pattern en vez de max_cols
            row_pattern = { 1, 7 }, -- fila 1: solo la barra; fila 2: navegación (como el layout clásico)
            label_size = 0, -- tamaño (pt) de la etiqueta en modo ícono, 0 = auto
            label_inside = false,
            items = { "slider", "skim_prev_chapter", "skim_toc", "skim_next_chapter", "skim_page", "skim_prev_bookmark", "skim_bookmark_toggle", "skim_next_bookmark" },
        },
        toc = {
            enabled_r = true, -- reader only: needs an open book with a table of contents
            show_title = true,
            collapse = false,
            show_page_numbers = true,
            show_chapter_pages = true, -- número de páginas del capítulo (requiere "Show chapter length" nativo)
            show_chapter_time = true, -- tiempo estimado del capítulo (requiere el plugin Statistics)
            max_visible_rows = 6, -- filas por página; 0 = sin límite (no pagina)
            max_depth = 0, -- 0 = sin límite de profundidad expandible
            indent_size = 14, -- px per depth level, before DPI scaling
            row_font_size = 0, -- 0 = usa el tamaño de fuente global de los botones
        },
        pagebrowser = {
            enabled_r = true,
            show_title = true,
            collapse = false,
            thumbnail_height = 220,
        },
        footer = {
            enabled_f = true,
            enabled_r = true,
            show_title = true,
            use_zenfooter = false,
            items = {"memusedp", "storageusedp", "time", "battery", "auxbattery"}
        },
    },
    custom_actions = { },
    style = {
        padding = 5,
        h_gap = 4,
        v_gap = 4,
        action_size = 64,
        action_radius = 32,
        toggle_action_size = 64,
        toggle_action_radius = 32, -- forma de los botones Luz/Noche: 0 = cuadrado, toggle_action_size/2 = círculo
        btn_width = 45,
        btn_radius = 7,
        btn_bordersize = 1.5,
        btn_font_size = 16,
        slider_ticks_width = 1,
        panel_shadow_width = 3, -- ancho de la sombra del panel (en píxeles, antes de escalar por DPI)
        panel_shadow_intensity = 0.55, -- 0 = negro (sombra bien marcada), 1 = blanco (casi invisible)
        button_shadow_width = 2, -- ancho de la sombra de botones/sliders/tarjetas (en píxeles, antes de escalar por DPI)
        button_shadow_intensity = 0.6, -- 0 = negro (sombra bien marcada), 1 = blanco (casi invisible)
        rect_button_bordersize = 1.5, -- ancho de borde propio de los botones en modo rectángulo (independiente de btn_bordersize, en píxeles antes de escalar por DPI)
        rect_button_border_intensity = 0, -- color del borde en modo rectángulo: 0 = negro, 1 = blanco
    },
    open_on_start = true,
    add_exit_tab = true,
    add_quickmenu_tab = true,
    idx_quickmenu_tab = 1,
}

local function copyMissing(dst, defaults)
    for key, value in pairs(defaults) do
        if dst[key] == nil then
            if type(value) == "table" then
                local copy = {}
                for k, v in pairs(value) do
                    copy[k] = v
                end
                dst[key] = copy
            else
                dst[key] = value
            end
        end
    end
end

function Config.load()
    local cfg = _settings:readSetting("quick_menu_settings") or {}
    cfg.sections = cfg.sections or {}

    -- section_order
    if cfg.section_order == nil then cfg.section_order = Config.DEFAULTS.section_order end

    -- drop ids that no longer exist, then append any new ids (e.g. from a plugin
    -- update) that are missing from the user's saved order, so new sections
    -- become visible without requiring a manual "reset sections order".
    do
        local seen = {}
        local cleaned = {}
        for _, section_id in ipairs(cfg.section_order) do
            if Config.DEFAULTS.sections[section_id] and not seen[section_id] then
                table.insert(cleaned, section_id)
                seen[section_id] = true
            end
        end
        for _, section_id in ipairs(Config.DEFAULTS.section_order) do
            if not seen[section_id] then
                table.insert(cleaned, section_id)
                seen[section_id] = true
            end
        end
        cfg.section_order = cleaned
    end

    -- sections level 1
    for section_id, section_data in pairs(cfg.sections) do
        if not Config.DEFAULTS.sections[section_id] then cfg.sections[section_id] = nil end
    end

    -- sections level 2
    for section_id, defaults in pairs(Config.DEFAULTS.sections) do
        cfg.sections[section_id] = cfg.sections[section_id] or {}
        for param_key, param_value in pairs(cfg.sections[section_id]) do
            if defaults[param_key] == nil then cfg.sections[section_id][param_key] = nil end
        end
        copyMissing(cfg.sections[section_id], defaults)
    end

    -- global cleaning
    for key, value in pairs(cfg) do
        if key ~= "sections" then
            if Config.DEFAULTS[key] == nil then cfg[key] = nil end
        end
    end

    -- global populating
    if cfg.open_on_start == nil then cfg.open_on_start = Config.DEFAULTS.open_on_start end
    if cfg.add_exit_tab == nil then cfg.add_exit_tab = Config.DEFAULTS.add_exit_tab end
    if cfg.add_quickmenu_tab == nil then cfg.add_quickmenu_tab = Config.DEFAULTS.add_quickmenu_tab end
    if cfg.idx_quickmenu_tab == nil then cfg.idx_quickmenu_tab = Config.DEFAULTS.idx_quickmenu_tab end

    -- style cleaning
    cfg.style = cfg.style or {}
    for key, value in pairs(cfg.style) do
        if Config.DEFAULTS.style[key] == nil then cfg.style[key] = nil end
    end

    -- style populating
    for key, value in pairs(Config.DEFAULTS.style) do
        if cfg.style[key] == nil then cfg.style[key] = value end
    end

    --
    cfg.custom_actions = cfg.custom_actions or {}

    return cfg
end

function Config.save(cfg, no_flush)
    _settings:saveSetting("quick_menu_settings", cfg)
    if not no_flush then _settings:flush() end
end

function Config.saveAndRefresh(ctx, no_flush)
    -- save
    local config = ctx.config
    if config then Config.save(config, no_flush) end
    -- refresh (debounced): touch_menu:updateItems() rebuilds the whole
    -- panel (icons, cover thumbnails, action scans...), which is expensive.
    -- Doing that synchronously on every single call -- e.g. a burst of
    -- toggles tapped one after another -- can make the UI visibly stutter
    -- or lock up for a moment. Coalesce any such burst into a single
    -- rebuild on the next UI tick instead, so it still updates live
    -- without blocking the current tap's own feedback.
    local touch_menu = ctx.touch_menu
    if not (touch_menu and touch_menu.updateItems) then return end
    if touch_menu._qs_pending_config_refresh then return end
    touch_menu._qs_pending_config_refresh = true
    UIManager:nextTick(function()
        touch_menu._qs_pending_config_refresh = false
        if touch_menu.updateItems then touch_menu:updateItems() end
    end)
end

return Config
